# ARIES profiling raw artifacts

Start with COMMANDS.md for complete observed commands and command-index.json for ToolCall/process identities, original timing boundaries and perf task-event selectors. For stop retries, use the highest numbered command-navigation-N.json; earlier indexes remain unchanged.
profile-index.json records the capture identity, scope, tool configuration, clocks and outcomes.
export-manifest.json records file sizes, SHA-256 and transfer status.
Tool subdirectories contain native output and stderr. Related ToolCall/process lifecycle evidence remains in this attempt's existing native evidence files.
A domain is ECS or Sandbox; their PIDs and monotonic clocks are independent.
No performance analysis or flame graphs are generated. Missing, unsupported, partial and zero-event captures are distinct.
Use the recorded tool version to read binary artifacts. perf.script, when present, was decoded against the Guest environment before deletion; it does not guarantee complete re-symbolization of perf.data.
