ARIES runtime profiling capture
The owner attaches to a waiting same-PID launch gate before requesting native exec.
Inspect per-tool initialization_covered and readiness evidence; launch alone is not readiness.
exec_requested is a pre-exec timestamp, not the exact exec syscall time; command-line change confirms continuation.
Guest creation before first executable access is excluded. Interval tools retain their sampling resolution.
Guest scope includes unrelated services and the collector. Runtime scope follows each tool's stated limits.
profile-index.json records tool status, clocks, PID birth identities, stop evidence and SHA-256 artifacts.
Collector exit and tool exits are independently confirmed; partial is an observation failure, not a workload result.
Raw files and native guest decodes are supplied for offline analysis; no flamegraph or attribution is generated.
perf.data retains native events; perf.script resolves symbols in the measured guest before deletion.
symbols/ retains observed maps and available perf-PID.map files, not executable/library copies.
Short-lived or later-loaded dynamic symbols can be missing; inspect symbol_capture and native decode errors.
lost_samples=null means loss was not quantified, not zero. Output shares the observed filesystem unless proved otherwise.
max_file_bytes is a hard per-file tool limit; reaching it marks partial. Multi-file captures can exceed it in total.
The index excludes itself and mutable nested indexes from hashing. Archive the entire directory including this file.
