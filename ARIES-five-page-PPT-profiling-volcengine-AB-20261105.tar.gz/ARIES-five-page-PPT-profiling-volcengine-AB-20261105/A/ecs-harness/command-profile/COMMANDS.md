# 命令与 Profiling 原件目录

执行域：ecs；角色：harness；命令账本状态：runtime_context_only。

从下表找到命令，再查看完整命令和 JSON 中的 `perf_selection`。该字段只提供同域内已证实的内核进程生命期与原件位置，不计算热点、CPU 用量或火焰图。系统级资源文件属于整体背景，不能直接归给某条命令。短命令可能没有 CPU 采样点。

采样丢失状态：`native_decode_retained_not_quantified`。进程关联成功不表示全树、全部采样或零丢失。

- This ECS Harness capture has no local command ledger; A Tool commands belong to the Sandbox Worker capture.

| 序号 | ToolCall | PID | 命令记录 | 进程终态 | perf 进程关联 |
|---|---|---:|---|---|---|
