# 五页 PPT：火山 A/B 完整 Profiling 原件包（2026-11-05）

本轮真实火山 veFaaS A/B 均完成五页 PPT 任务，独立评分为 1。A：32 条命令，出生身份 32/32，perf matched 32/32；B：39 条命令，出生身份 39/39，perf matched 39/39。三域六工具采集、启动期就绪、原件大小/SHA 与原生 perf 回读通过。数量来自本轮原始命令账本与导出清单；其他云的历史结果不计入本包。

**版本差异必须随跨云分析一起保留：**华为 r2 交付使用 Runner `8e57893c0eef0eb1cc6ed93cc3b3f2ccab701dce90a54ec76182a590f00068fd`；本包使用独立修复版 `aries-volcengine-fix`，SHA `4d1b431d36fce8ab815a0e4b129d3f6467a7ba54548d4db5270b3c003195f6bf`。修复将 root 拥有的 profiling 原件目录从 `/run` 移到 `/var/tmp/aries-jiuwen-…-profile`，配套启动门位于其 `-launch` 同级目录，并修正 ENOSPC 时采集器和专用 UID 的停止/确认流程。原业务运行时仍保留 `/run` 位置。两边 Runner 并非同一二进制，不能把差异全部归因于云厂商。

本轮沿用原火山精确镜像、技能/版本、4 CPU / 8192 MiB 模板，以及与华为对应 placement 相同的 Tape；A 与 B 各自使用不同 Tape。前轮火山 B 的 Harness 虽成功，停止未确认，评分为 `blocked_isolation`，不是成功样本，其不完整 profiling 不并入本包。旧故障证据单独保留在 `/opt/aries-artifacts/profiling-volcengine-20261105/B/`；本包只使用新 ROOT 的两次完整回放。

| 原件入口 | 原始导出文件 | 字节 | 命令导航 |
| --- | ---: | ---: | --- |
| `A/ecs-harness/command-profile/` | 37 | 133,595,984 | runtime_context_only；Tool 命令归 Sandbox Worker |
| `A/sandbox-worker/command-profile/` | 108 | 12,786,546 | 32 条命令，32 matched |
| `B/sandbox-harness/command-profile/` | 109 | 119,302,883 | 39 条命令，39 matched |

合计 254 份原始导出文件、265,685,413 字节。包内还包含命令账本、评分和 PPT、来源证明、验收回执与说明，所以整包文件数不等于原始导出数。采样原件用于后续分析，本包不生成热点结论、自动火焰图或 Console。

## 先从哪里开始

1. 先核对压缩包旁的 SHA；解压后执行 `sha256sum -c SHA256SUMS`，macOS 可用 `shasum -a 256 -c SHA256SUMS`。
2. 看 `A/pptx/`、`B/pptx/` 的输入及输出导航，打开 `evaluation/` 中原始 PPT 和 Verifier 结果。中间 PPT 同样保留，不将多个文件计为多次任务。
3. 看对应执行域的 `command-profile/COMMANDS.md`，按序号阅读实际完整 cmd、ToolCall、进程身份和返回码。
4. 在同目录 `command-index.json` 查询原始事件行号和 `perf_selection`，再定位 `perf.script`、`perf.data` 与符号材料。
5. 查看 `profile-index.json` 和各工具索引，确认版本、参数、范围、就绪、终态、丢失/截断等状态。具体操作见 `COLLECTION.md`。

## A/B 分别在哪里采

- A 分体式：Jiuwen Harness 在 ECS 容器；业务命令在火山 Sandbox 的 Worker 中。两域独立采集。ECS 目录为 Harness 运行时上下文，不能把 Worker 的命令复制成 ECS 本地执行。
- B 一体式：Harness 与真实 Tool 命令都在同一个 Sandbox。`B/sandbox-harness/` 的名称表示附着根，同时覆盖已实际观察到的 Tool 后代，不是只采 Harness。
- 各域有自己的 PID 空间、boot_id 和单调时钟；相同 PID、命令文本或相近时间都不能跨域建立关联。

目录主要包括三域 `command-profile/`、相邻 `jiuwen-process-events.jsonl` 和 `jiuwen-process-index.json`、两组 `identity/`、`evaluation/`、`pptx/`、`completion.json`、`run-cleanup-proof.json`、根部 `verification/`、`receipts/`、`manifest.json`、`SHA256SUMS` 与 `collection-provenance.json`。请保留相对目录结构。

## 每项工具是否采集

以下逐域状态来自本轮配置与原始 `profile-index.json`，未选择工具的 UNRUN 仅表示本轮未采集。

| 执行域 | 工具 | 本轮状态 |
| --- | --- | --- |
| `A/ecs-harness` | perf | 已采集；completed；scope=runtime |
| `A/ecs-harness` | vmstat | 已采集；completed；scope=guest |
| `A/ecs-harness` | iostat | 已采集；completed；scope=guest |
| `A/ecs-harness` | mpstat | 已采集；completed；scope=guest |
| `A/ecs-harness` | sar | 已采集；completed；scope=guest |
| `A/ecs-harness` | pidstat | 已采集；completed；scope=runtime |
| `A/ecs-harness` | numastat | 未选择 / UNRUN |
| `A/ecs-harness` | dmesg | 未选择 / UNRUN |
| `A/ecs-harness` | strace | 未选择 / UNRUN |
| `A/ecs-harness` | bpftrace | 未选择 / UNRUN |
| `A/ecs-harness` | blktrace | 未选择 / UNRUN |
| `A/sandbox-worker` | perf | 已采集；completed；scope=runtime |
| `A/sandbox-worker` | vmstat | 已采集；completed；scope=guest |
| `A/sandbox-worker` | iostat | 已采集；completed；scope=guest |
| `A/sandbox-worker` | mpstat | 已采集；completed；scope=guest |
| `A/sandbox-worker` | sar | 已采集；completed；scope=guest |
| `A/sandbox-worker` | pidstat | 已采集；completed；scope=runtime |
| `A/sandbox-worker` | numastat | 未选择 / UNRUN |
| `A/sandbox-worker` | dmesg | 未选择 / UNRUN |
| `A/sandbox-worker` | strace | 未选择 / UNRUN |
| `A/sandbox-worker` | bpftrace | 未选择 / UNRUN |
| `A/sandbox-worker` | blktrace | 未选择 / UNRUN |
| `B/sandbox-harness` | perf | 已采集；completed；scope=runtime |
| `B/sandbox-harness` | vmstat | 已采集；completed；scope=guest |
| `B/sandbox-harness` | iostat | 已采集；completed；scope=guest |
| `B/sandbox-harness` | mpstat | 已采集；completed；scope=guest |
| `B/sandbox-harness` | sar | 已采集；completed；scope=guest |
| `B/sandbox-harness` | pidstat | 已采集；completed；scope=runtime |
| `B/sandbox-harness` | numastat | 未选择 / UNRUN |
| `B/sandbox-harness` | dmesg | 未选择 / UNRUN |
| `B/sandbox-harness` | strace | 未选择 / UNRUN |
| `B/sandbox-harness` | bpftrace | 未选择 / UNRUN |
| `B/sandbox-harness` | blktrace | 未选择 / UNRUN |

fio 是显式工作负载，本轮未运行，不随采集器自动启动。

## 六项已选工具的用途与边界

| 工具 | 本轮配置 | 能看什么及主要边界 |
| --- | --- | --- |
| perf | runtime，record，99 Hz，fp 调用栈 | CPU 采样、FORK/EXIT/COMM 生命周期及可用符号；保留原始 perf.data、原生解码 perf.script 和 Python perf map。身份已关联不等于每条短命令都有 CPU 样本 |
| vmstat | guest，1 秒 | 系统队列、内存、交换、I/O 和 CPU 概况；不是逐命令独占用量 |
| iostat | guest，1 秒 | CPU 与块设备 I/O；不能直接归因到单条 cmd |
| mpstat | guest，1 秒 | 各 CPU 活动；周期可能错过短操作 |
| sar | guest，1 秒 | 实际 argv 所选系统指标，保留原生二进制和文本 |
| pidstat | runtime，1 秒 | 所选 PID/线程的周期统计，按原件记录 I/O 维度权限和范围；不承诺覆盖全部短命后代 |

strace、numastat、dmesg、bpftrace、blktrace 可单独配置，本轮持续采集未选择；fio 是显式工作负载，不能自动混入 PPT。ECS 容器可见的 guest 统计包含其可见内核/系统视图，不代表容器专属资源归因。

## 出生身份与跨 tick 关联修复如何读

固定 CPython 3.12.15 observer 在原生 Popen 返回后、watcher 注册前读取一次出生身份。没有暂停/包装命令，没有新增回收器、信号或流读取；原 stdout、stderr、退出码、后台与取消语义保留。observer 镜像沿用已通过原生行为回归的相同版本；本轮 Runner 的独立发布检查、火山业务和原件验收分别核对。

本轮 Runner 来自 `/opt/aries-artifacts/profiling-volcengine-fix-20261105/source` 的独立冻结源码和 `release/source-manifest.json`。随包 release 回执记录该修复候选的 build/test/race/lint/integration 五项检查，不能当作火山 A/B 执行结果。火山镜像发布与模板准备仍引用冻结 observer binding 指定的原成功 attempt；其中 Guest UNRUN / NO_SANDBOX_STARTED 是发布准备当时的状态，本轮真实业务结果另见 A/B completion 与验收回执。

`connected.monotonic_ns` 仍是原 connection 回调时刻。新增 `pid_birth_capture` 独立记录实际读取来源、起始单调时间、PID、出生 ticks、PPID、状态和错误；提前读取成功时，`pid_birth_callback` 保留回调时的再次读取结果。若回调已经 ENOENT，cwd 保持未知，但有依据的提前出生身份可以继续用于关联。读取时间不是内核 fork/exec 时间。

命令索引包含实际入口的完整 shell 原文或 exec argv，不记录 env/stdin，不用 COMM 短名称反推命令。一个 ToolCall 可以产生多个进程，也可能没有子进程。`completed` 仅表示观察到进程退出，返回非零不能改成零；整题成功另看独立 Verifier。

perf 生命周期匹配先要求同执行域与 boot_id、原生 PID/PPID 一致，且 spawn 请求到 connection 回调的闭区间内只有一个同 PID/PPID 的进程 FORK。再将出生 tick 的半开区间与校准后的 spawn→FORK 因果区间求交：`spawn + offsetLow < birthHigh` 且 `FORK + offsetHigh >= birthLow`。offset 上下界来自保留的 boottime/monotonic 校准；出生 tick 量化边界保持左闭右开。多个候选、错误父进程、出生过早或过晚、无效时钟均不能通过。没有添加 ±tick 容差，也不要求短命令的退出晚于 connection 回调。

后代只沿实际 FORK/EXIT/COMM 关系连接。不使用命令 hash 或时间最近作为身份替代。`matched` 不承诺完整进程树、零采样丢失或完整函数符号。

## 未选择工具与 BPF 范围

bpftrace、strace、numastat、dmesg、blktrace 本轮均未选择，状态为 UNRUN。BPF 没有本轮 attach、事件或停止原件；不能把未选择解释为零事件、成功采集或火山平台不支持。华为的 BPF 内核诊断不用于判断火山能力。若以后单独授权探测或启用，以对应域的实际工具证据另行验收，不影响本次六工具 PPT 的验收口径。

## 启动期、开关与容量

采集器在同 PID 启动门前启动，取得工具自己的 native ready 后放行原生 Harness/Worker exec，再覆盖可观察初始化、业务与退出。门等待与实际初始化分开记录；Sandbox 从创建到可执行前的内部过程不在范围。1 秒周期及采样频率不保证每个瞬间都被记录。

全局 `profiling.enabled=false` 优先。全局开启时仅运行未显式关闭的工具；`tools: []` 或全部 disabled 不启动采集器/采集启动门。省略 tools 才兼容默认 perf。A 外置 Harness 额外采集由 `external_harness=true` 控制，B 不需要该开关。

默认每文件 2 GiB，可配置放大；传输按 64 MiB 块导出并核对整 SHA。就绪、停止、导出和解码都有独立预算；缺失、失败、unsupported、partial、采样零值分别表达，不用空文件填成功。

每文件限额不等于底层文件系统剩余容量。此次迁移改变 profiling 及配套启动门存放位置，不移动原 Harness/Worker 运行时。磁盘写入失败时，停止流程仍尝试终止自有工具和业务 UID；只有独立身份/进程检查证明停止，才能确认停止，不能以诊断文件写出或进程不存在的单一现象代替。写盘失败仍保留 partial/错误，不能成为完整采集的通过证据。

## 任务、PPT 与验收范围

原任务：`幻灯片 生成一份关于大模型发展的pptx材料，写5页。`

A/B 复用已准备的火山模板，模板配置为 4 vCPU / 8192 MiB；SDK 请求资源值与实际 Guest 观测分别保留，不互相替代。A/B 各复用与对应华为 r2 placement 相同的原成功 Tape，使用 timing=zero、replay_policy=workload 的即时工作量回放与真实工具。zero 不重放录制等待，仍有真实 HTTP、客户端及工具等待。两种 placement 的 Tape 不同，本轮用于采集能力验收，不能据 A/B 耗时直接比较部署方式。输入文字从冻结源码明确摘录，记录源文件 SHA，不冒充独立上传文件。

`evaluation/` 原样保留评分目录及其全部 PPT，`pptx/` 给出导航；文件数量包含中间件，不等于成功任务数。

- A：`evaluation/candidate-2779376294/decks/projects/llm-development/output/content.pptx`。页数和 SHA 见原评分目录及 `pptx/` 导航。
- A：`evaluation/candidate-2779376294/decks/projects/llm-development/output/final.pptx`。页数和 SHA 见原评分目录及 `pptx/` 导航。
- B：`evaluation/candidate-2120573356/decks/projects/llm-development/output/content.pptx`。页数和 SHA 见原评分目录及 `pptx/` 导航。
- B：`evaluation/candidate-2120573356/decks/projects/llm-development/output/final.pptx`。页数和 SHA 见原评分目录及 `pptx/` 导航。
- B：`evaluation/candidate-2120573356/decks/projects/llm-development/output/template-clean.pptx`。页数和 SHA 见原评分目录及 `pptx/` 导航。
- B：`evaluation/candidate-2120573356/decks/projects/llm-development/output/大模型发展.pptx`。页数和 SHA 见原评分目录及 `pptx/` 导航。

两次独立评分均为 1，Harness Stop / Bridge revoke、任务与基础设施清理、4 个任务/评分 Sandbox 删除确认均通过。网络策略仍为 `assumed_not_enforced`，不声称已强制禁网或 fully isolation-verified Goodput。

## 复现身份

- A Run ID：`20261105T043550.240890394Z-profiling-volcengine-fix-20261105-a`。
- B Run ID：`20261105T043111.246930319Z-profiling-volcengine-fix-20261105-b`。
- Binary SHA：`4d1b431d36fce8ab815a0e4b129d3f6467a7ba54548d4db5270b3c003195f6bf`。
- 独立冻结源码：`/opt/aries-artifacts/profiling-volcengine-fix-20261105/source`；本轮候选 release 回执 SHA：`255192a8320dd979a7dfe49e806fea4dba9d857cf579f0502973cf15a963c552`。
- 完整源码 SHA 清单（不含源码正文）回执 SHA：`2998f3a31d40d403e9dca058a89213baa14bba7997d0e8fd52807004ec76ddba`；包内位置见 `collection-provenance.json`。
- 火山发布回执 SHA：`581a42e2e4ef6bedfab2b65b4679a066827bfe6701e984e78b2ce589e177acea`；模板回执 SHA：`a912717145c5f59a7467f746b0ba1202d998ceb6aa8e9647d5f439da71600923`。
- 镜像与模板、三域配置、Tape SHA 和来源文件见 `collection-provenance.json` 与各组 `profiling-config.json`。
- 本包验证范围为真实任务、命令/身份/内核来源一致性、原件完整性和原生可读性，不提供自动性能归因结论。

不包含完整 Tape、私有 env/profile、密钥或完整模型 SSE。原件保留真实命令/输出；已知私有值扫描结果写入封包回执，不宣称可识别任意未知秘密。
