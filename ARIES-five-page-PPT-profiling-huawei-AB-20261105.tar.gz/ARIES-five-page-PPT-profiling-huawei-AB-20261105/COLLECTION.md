# 原件读取与命令导航说明

本轮A/B独立评分均为1，三域原件与原生回读通过。本文说明如何从完整命令找到原件；结果总表和实际缺口见`README.md`，不生成性能分析结论。

## 1. 核验与选择执行域

先核验下载包的SHA，再在解压后的包根目录执行：

```sh
sha256sum -c SHA256SUMS
```

macOS可使用`shasum -a 256 -c SHA256SUMS`。保留目录结构，尤其是命令索引引用的域父目录账本和完整perf符号目录。`manifest.json`区分复制原件与明确提取的验收材料；不要把README的说明当成原生测量。

选择`A/sandbox-worker/command-profile`查A的业务Tool命令。`B/sandbox-harness/command-profile`对应“B：Sandbox 内 Harness + Tool”，既保留Harness启动运行，也有实际Tool cmd及perf已观察后代的生命期索引；路径名不表示只采Harness。A的`ecs-harness/command-profile`是外置Harness上下文，没有本地命令账本时`runtime_context_only`是边界说明；不能从另一个域拼出一份本地命令列表。六工具范围各异，guest周期统计仍不能全部按cmd归因。

## 2. 从完整cmd找到ToolCall与原生进程

在所选域打开`COMMANDS.md`。表格中的序号跳转到实际`create_subprocess`入口的完整shell命令或exec argv、cwd、ToolCall、process_id、回调时间与returncode。shell命令原文和exec参数数组分别保留；shell展开后的子命令不由字符串拆分推导。

原生执行计划可能加入stream缓冲包装或改为`bash -c`，因此入口参数可能不同于ToolCall请求中的command。通过request_id加tool_call_id查看原始请求/权威span的实际关联；记录文本相同或不同的事实，不把包装差异当作关联失败，不反向剥壳还原。

对应`command-index.json.commands[]`中，`ordinal`是目录序号，`process_id`是原生进程记录ID，`identity.tool_call_id`是原生关联。完整原始记录在`spawn`、`connected`、`exit`或`spawn_failure`中，原生命令账本行号在顶层`source_lines`中。`sources`固定原件路径、大小和SHA，用它回到相邻的`../jiuwen-process-events.jsonl`与生产者索引。

可用标准Python查看某一序号的原始索引对象。先进入所选域的`command-profile/`，将末尾的`1`改成需要的序号：

```sh
python3 - 1 <<'PY'
import json, sys
from pathlib import Path
index = json.loads(Path('command-index.json').read_text())
ordinal = int(sys.argv[1])
rows = [row for row in index['commands'] if row['ordinal'] == ordinal]
if len(rows) != 1:
    raise SystemExit('该序号不存在或不唯一；检查执行域与索引状态')
print(json.dumps(rows[0], ensure_ascii=False, indent=2))
PY
```

这里只展示已有对象，不补PID、命令、退出码或关联。若命令不存在，先看域角色、索引issues和生产者coverage；不能将“没找到”直接解释成该ToolCall没有执行。

## 3. 如何使用kernel进程生命期选择

读取该条命令的`perf_selection`：

| 字段 | 用途 |
| --- | --- |
| `status`、`reason`、`issues` | 判断是`matched`、`partial`还是`unknown`及原因；遇到unknown不自行按PID/近邻时间补齐 |
| `kernel_fork_ns`、可选`kernel_exit_ns` | 根进程的内核观测边界；缺退出保持缺失，不能用回调或run结束时间替代 |
| `processes[]`、`threads[]` | 当前证据确定的生命期集合；每项PID/TID、parent_pid/parent_tid、fork/exit时间分别保留 |
| `source_lines` | 本次内核生命期选择在原始`perf.script`中的行号，与命令账本的行号属于不同文件 |
| 各生命期的`comm_events[]` | 内核COMM/exec名字事件；COMM不是完整argv或可执行文件路径 |

`command-index.json.perf_script`给出原始perf文本相对路径。按`perf_selection.source_lines`回看FORK/EXIT/COMM记录，再结合所列PID/TID及生命期区间选择后续需要读取的原始事件。PID会重用，应始终连同boot_id、执行域和时间边界使用；不能只运行一次全文件“按PID筛选”就把所有同号样本当成当前命令。

内核生命期锚点要求同域/boot、PID/PPID与spawn→connected窗口内唯一FORK，再检查出生tick半开区间和校准后的spawn→FORK因果区间相交；后代仅沿实际观察到的、无歧义父生命期连接。缺失FORK、缺失EXIT、丢失事件、模糊父代、时钟材料不足都会影响结果。所列集合不承诺所有OS后代都出现，也不等于所有这些进程都有CPU采样点。

这里的kernel选择不表示筛选内核态CPU调用栈，也不计算CPU时间、百分比或命令墙钟。命令请求/连接/退出回调是原生观察边界，内核FORK/EXIT是另一个来源；两者不混写为精确执行耗时。

本轮 r2 的逐条出生身份与关联结果见随包 birth-validation 回执。`connected.pid_birth_capture` 保存提前读取身份，`connected.pid_birth_callback` 保留回调读取诊断；两者的单调时间和原 connection 回调时间分别保留。历史 11 月 4 日 B 第 5 条仍是 unknown；r1 A 出生身份 32/32 但 perf 关联 31/32、B 出生身份及关联 39/39，均不回填改判。

r2 关联要求同域/boot、PID/PPID、spawn→connection 窗口内唯一 FORK；候选唯一性先于出生区间检查，不能用出生 tick 过滤掉第二个候选。出生 tick 半开区间必须与校准后的 [spawn + offsetLow, FORK + offsetHigh] 有交集，不再要求较晚的 FORK 点位于出生 tick 内。没有 ±tick 容差、命令 hash 或近邻匹配；短命令允许在 connection 回调前退出。后代仍按原始内核事件的父子关系导航。

## 4. 从索引进入各工具原件

查看`profile_files`里的原始相对路径、大小、SHA和导出状态，再结合`profile-index.json.tools`定位实际工具目录。命令索引只为原件提供入口，不把vmstat/iostat/mpstat/sar等guest级文件切分成逐命令独占消耗。

perf应整体保留`perf.data`、`perf.script`、各索引、stderr和`symbols/`。`perf.script`在原运行环境解码，适合先检查原始事件与可读符号；它不替代二进制。需要再次原生回读时，使用记录的兼容工具版本，命令与状态以本包验收文件中的实际argv为准。不同版本、缺少原ELF/共享库/debug信息或地址复用仍会限制重新符号化。

Harness/Worker启用的原生Python perf支持会生成相应`perf-PID.map`；任意Tool命令没有因此被注入新环境或参数，不能承诺每个Python Tool都有完整函数符号。`py::`存在只说明字面可读性，不是热点、函数总数或覆盖率。

sysstat二进制与文本、各工具stdout/stderr及版本一并保留。某个文件可读不证明对应工具完整成功；检查启动就绪、终止确认、截断、丢失、unsupported/failed/partial等状态。1秒周期可以遗漏短命令；零采样、工具未启用、权限不足和产物缺失分别处理。

## 5. 复用采集配置与开关

本轮使用的profiling块如下。它是片段，复制时保留原完整profile的模型、Tape、版本与工作负载字段；不要把此片段当作独立可运行配置。

```json
{
  "profiling": {
    "enabled": true,
    "frequency_hz": 99,
    "call_graph": "fp",
    "max_file_bytes": 2147483648,
    "external_harness": true,
    "tools": [
      {"name": "perf", "enabled": true, "mode": "record", "scope": "runtime"},
      {"name": "vmstat", "enabled": true, "scope": "guest", "interval_seconds": 1},
      {"name": "iostat", "enabled": true, "scope": "guest", "interval_seconds": 1},
      {"name": "mpstat", "enabled": true, "scope": "guest", "interval_seconds": 1},
      {"name": "sar", "enabled": true, "scope": "guest", "interval_seconds": 1},
      {"name": "pidstat", "enabled": true, "scope": "runtime", "interval_seconds": 1}
    ]
  }
}
```

A需要双域时显式`external_harness=true`；B使用false。关闭全局开关时即使各工具为true也不采集。全局开启后可单项设false；显式`tools: []`或全部false不启动collector。省略tools才是旧perf默认语义，不能与空数组混淆。

本轮命令导航依赖原生命令观测及实际导出的perf record task事件。只选其他工具、perf stat、缺命令出生身份、无对应perf原件或时钟不匹配时，perf关联应保持unknown。索引不会为了补关联自动开启未选择的工具，也不为每条cmd额外运行strace。

## 6. 检查PPT与独立验收

先读A/B各自`pptx/`中的输入摘录和出处SHA，再按输出导航清单查全部实际PPTX及原路径，包括评分失败的中间产物。`evaluation/`整目录保持原样，内含`decks/`、manifest/capture/report及实际stdout/stderr；清单引用`../evaluation/...`，避免重复复制或破坏相对路径。评分目录外的PPTX另存`pptx/extra/`并记录原路径。通过Verifier报告确认被评分文件、原五页结构与内容检查结果，不只依据CLI退出码、Harness完成或某个PPT文件存在判断任务成功。

分别检查Verifier、Harness Stop、Bridge revoke、任务清理、基础设施清理、两个Sandbox absence和自有adapter删除。采集状态、命令账本完整性与业务评分可以不同；已保留的失败、unknown与条件跳过不由最终成功包覆盖。

本轮实际结果：A：32 条命令，出生身份 32/32，perf matched 32/32；B：39 条命令，出生身份 39/39，perf matched 39/39。三域 271 份原始导出，三份 perf 原生回读通过。BPF 在华为同进程完整权限、无 seccomp 过滤时直接 map syscall 仍 ENOSYS；弱入口和 tracefs 未注册证据保存在 receipts，实际内核 CONFIG 未取得。BPF 按用户决定暂缓，作为本轮未采集的已知遗留；平台交接说明与便携探针随件保留，以后平台能力恢复时再复验。ECS read=4 控制组不改变华为状态。详细数量、PPT、Run ID和版本见`README.md`。
