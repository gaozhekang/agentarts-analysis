# 五页 PPT：A/B 完整 Profiling 原件包（2026-11-05，r2）

本轮 r2 真实华为 A/B 均完成五页 PPT 任务，独立评分为 1。A：32 条命令，出生身份 32/32，perf matched 32/32；B：39 条命令，出生身份 39/39，perf matched 39/39。三域六工具采集、启动期就绪、原件大小/SHA 与原生 perf 回读通过。出生身份与跨 tick 关联修复经过本轮真实回放验证；11 月 4 日 B 第 5 条的 unknown 和 r1 A 的 31/32 关联均保留为历史结果，不回填改判。

| 原件入口 | 原始导出文件 | 字节 | 命令导航 |
| --- | ---: | ---: | --- |
| `A/ecs-harness/command-profile/` | 37 | 135,240,241 | runtime_context_only；Tool 命令归 Sandbox Worker |
| `A/sandbox-worker/command-profile/` | 113 | 12,743,577 | 32 条命令，32 matched |
| `B/sandbox-harness/command-profile/` | 121 | 82,886,941 | 39 条命令，39 matched |

合计 271 份原始导出文件、230,870,759 字节。包内还包含命令账本、评分和 PPT、来源证明、验收回执与说明，所以整包文件数不等于原始导出数。采样原件用于后续分析，本包不生成热点结论、自动火焰图或 Console。

## 先从哪里开始

1. 先核对压缩包旁的 SHA；解压后执行 `sha256sum -c SHA256SUMS`，macOS 可用 `shasum -a 256 -c SHA256SUMS`。
2. 看 `A/pptx/`、`B/pptx/` 的输入及输出导航，打开 `evaluation/` 中原始 PPT 和 Verifier 结果。中间 PPT 同样保留，不将多个文件计为多次任务。
3. 看对应执行域的 `command-profile/COMMANDS.md`，按序号阅读实际完整 cmd、ToolCall、进程身份和返回码。
4. 在同目录 `command-index.json` 查询原始事件行号和 `perf_selection`，再定位 `perf.script`、`perf.data` 与符号材料。
5. 查看 `profile-index.json` 和各工具索引，确认版本、参数、范围、就绪、终态、丢失/截断等状态。具体操作见 `COLLECTION.md`。

## A/B 分别在哪里采

- A 分体式：Jiuwen Harness 在 ECS 容器；业务命令在华为 Sandbox 的 Worker 中。两域独立采集。ECS 目录为 Harness 运行时上下文，不能把 Worker 的命令复制成 ECS 本地执行。
- B 一体式：Harness 与真实 Tool 命令都在同一个 Sandbox。`B/sandbox-harness/` 的名称表示附着根，同时覆盖已实际观察到的 Tool 后代，不是只采 Harness。
- 各域有自己的 PID 空间、boot_id 和单调时钟；相同 PID、命令文本或相近时间都不能跨域建立关联。

目录主要包括三域 `command-profile/`、相邻 `jiuwen-process-events.jsonl` 和 `jiuwen-process-index.json`、两组 `identity/`、`evaluation/`、`pptx/`、`completion.json`、`run-cleanup-proof.json`、根部 `verification/`、`receipts/`、`manifest.json`、`SHA256SUMS` 与 `collection-provenance.json`。请保留相对目录结构。

## 六项实际采集工具

| 工具 | 本轮配置 | 能看什么及主要边界 |
| --- | --- | --- |
| perf | runtime，record，99 Hz，fp 调用栈 | CPU 采样、FORK/EXIT/COMM 生命周期及可用符号；保留原始 perf.data、原生解码 perf.script 和 Python perf map。身份已关联不等于每条短命令都有 CPU 样本 |
| vmstat | guest，1 秒 | 系统队列、内存、交换、I/O 和 CPU 概况；不是逐命令独占用量 |
| iostat | guest，1 秒 | CPU 与块设备 I/O；不能直接归因到单条 cmd |
| mpstat | guest，1 秒 | 各 CPU 活动；周期可能错过短操作 |
| sar | guest，1 秒 | 实际 argv 所选系统指标，保留原生二进制和文本 |
| pidstat | runtime，1 秒 | 所选 PID/线程的周期统计，按原件记录 I/O 维度权限和范围；不承诺覆盖全部短命后代 |

strace、numastat、dmesg、bpftrace、blktrace 可单独配置，本轮持续采集未选择；fio 是显式工作负载，不能自动混入 PPT。ECS 容器可见的 guest 统计包含其可见内核/系统视图，不代表容器专属资源归因。

## 出生身份与跨 tick 关联修复如何读

固定 CPython 3.12.15 observer 在原生 Popen 返回后、watcher 注册前读取一次出生身份。没有暂停/包装命令，没有新增回收器、信号或流读取；原 stdout、stderr、退出码、后台与取消语义保留。28 项回归已在基础镜像与新镜像各通过，完整 Go 发布检查通过。

`connected.monotonic_ns` 仍是原 connection 回调时刻。新增 `pid_birth_capture` 独立记录实际读取来源、起始单调时间、PID、出生 ticks、PPID、状态和错误；提前读取成功时，`pid_birth_callback` 保留回调时的再次读取结果。若回调已经 ENOENT，cwd 保持未知，但有依据的提前出生身份可以继续用于关联。读取时间不是内核 fork/exec 时间。

命令索引包含实际入口的完整 shell 原文或 exec argv，不记录 env/stdin，不用 COMM 短名称反推命令。一个 ToolCall 可以产生多个进程，也可能没有子进程。`completed` 仅表示观察到进程退出，返回非零不能改成零；整题成功另看独立 Verifier。

perf 生命周期匹配先要求同执行域与 boot_id、原生 PID/PPID 一致，且 spawn 请求到 connection 回调的闭区间内只有一个同 PID/PPID 的进程 FORK。再将出生 tick 的半开区间与校准后的 spawn→FORK 因果区间求交：`spawn + offsetLow < birthHigh` 且 `FORK + offsetHigh >= birthLow`。offset 上下界来自保留的 boottime/monotonic 校准；出生 tick 量化边界保持左闭右开。多个候选、错误父进程、出生过早或过晚、无效时钟均不能通过。没有添加 ±tick 容差，也不要求短命令的退出晚于 connection 回调。

r1 已实测 A 出生身份 32/32、B 出生身份及 perf 关联 39/39，但 A perf 关联为 31/32。A 第 2 条的出生 ticks=5533、时钟 100 Hz，对应区间 [55.33,55.34) 秒；perf FORK 为 55.340019251 秒。Linux 先设置 start_boottime，随后才调用 perf_event_fork，两者可以跨 tick。旧匹配器把 FORK 点误当出生时刻，r2 改用上述因果区间；r1 的原始账本、unknown 和回执不覆盖。

后代只沿实际 FORK/EXIT/COMM 关系连接。不使用命令 hash 或时间最近作为身份替代。`matched` 不承诺完整进程树、零采样丢失或完整函数符号。

## bpftrace 已知遗留与保留原件（用户暂缓）

11 月 5 日同一新 Build 的真实短 Sandbox，运行内核为 `6.6.0-72.0.0.76.r1893_129.hce3.x86_64`。同一探针进程 UID 0、CapEff `000001ffffffffff`、Seccomp=0、filters=0、NoNewPrivs=0，直接调用 `bpf(BPF_MAP_CREATE)` 仍为 errno 38 / ENOSYS；strace 中 MAP_CREATE、PROG_LOAD、BTF_GET_NEXT_ID 同样 ENOSYS。指定 `syscalls:sys_enter_read` 探针报 tracepoint not found、exit 1。

`__x64_sys_bpf` 是弱符号 W，`sys_ni_syscall` 是 T，所查 BPF 加载实现符号未见；`/proc/filesystems` 没有注册 tracefs，BTF 及相关 sysctl 路径也缺失。这组证据与运行内核使用未实现 BPF 的弱入口高度一致。实际 HCE 构建配置不可读，不能宣称已经核验 `CONFIG_BPF_SYSCALL=n`；最终需平台核对运行内核配置、定制实现和 syscall 分派。增加用户态工具、复制 BTF 或挂载目录不能补齐缺失的 syscall 实现。

`receipts/` 提供来自 `bpf-current-guest/`、`bpf-kernel-guest/`、`bpf-portable-guest/` 的诊断原件与清理回执、`bpf-ecs-control.json`、便携脚本 `probe_bpf_kernel_portable.py` 和平台交接说明 `huawei-bpf-platform-fix-20261105.md`；封包会在原文件名前加编号和来源目录，实际名称及 SHA 见 `manifest.json`。平台交接包保留独立诊断，不属于本轮六工具成功计数。

同一便携脚本在 ECS 控制组可创建 map、加载程序，并采到目标子进程 read=4；华为 Sandbox 仍失败，三个短 Guest 均 DELETE/404 确认。脚本退出 0 只表示诊断报告已生成，能力须看 `capability_status`：直接 map 创建、真实程序加载、指定目标的正数 read 计数全部成立才算通过。`--info`、`-l` 退出 0 或 ECS 控制组成功均不能替代 Sandbox 实际附着。

BPF 按用户决定暂缓，作为本轮未采集的已知遗留；上述失败诊断与平台交接材料原样保留。以后平台恢复所需 BPF 和 syscall tracing 能力时，再考虑以同脚本复验，并分别验收 A Worker、A ECS Harness、B Harness 的实际 BPF 就绪、业务、停止和原件。本次六工具结果不冒充 BPF 结果，也不推广为其他云或所有 BPF 永久不可用。

## 启动期、开关与容量

采集器在同 PID 启动门前启动，取得工具自己的 native ready 后放行原生 Harness/Worker exec，再覆盖可观察初始化、业务与退出。门等待与实际初始化分开记录；Sandbox 从创建到可执行前的内部过程不在范围。1 秒周期及采样频率不保证每个瞬间都被记录。

全局 `profiling.enabled=false` 优先。全局开启时仅运行未显式关闭的工具；`tools: []` 或全部 disabled 不启动采集器/采集启动门。省略 tools 才兼容默认 perf。A 外置 Harness 额外采集由 `external_harness=true` 控制，B 不需要该开关。

默认每文件 2 GiB，可配置放大；传输按 64 MiB 块导出并核对整 SHA。就绪、停止、导出和解码都有独立预算；缺失、失败、unsupported、partial、采样零值分别表达，不用空文件填成功。

## 任务、PPT 与验收范围

原任务：`幻灯片 生成一份关于大模型发展的pptx材料，写5页。`

A/B 各复用自己原成功 Tape，使用即时工作量回放与真实工具。两种 placement 的 Tape 不同，本轮用于采集能力验收，不能据 A/B 耗时直接比较部署方式。输入文字从冻结源码明确摘录，记录源文件 SHA，不冒充独立上传文件。

`evaluation/` 原样保留评分目录及其全部 PPT，`pptx/` 给出导航；文件数量包含中间件，不等于成功任务数。

- A：`evaluation/candidate-3578273805/decks/projects/llm-development/output/content.pptx`。页数和 SHA 见原评分目录及 `pptx/` 导航。
- A：`evaluation/candidate-3578273805/decks/projects/llm-development/output/final.pptx`。页数和 SHA 见原评分目录及 `pptx/` 导航。
- B：`evaluation/candidate-169150635/decks/projects/llm-development/output/content.pptx`。页数和 SHA 见原评分目录及 `pptx/` 导航。
- B：`evaluation/candidate-169150635/decks/projects/llm-development/output/final.pptx`。页数和 SHA 见原评分目录及 `pptx/` 导航。
- B：`evaluation/candidate-169150635/decks/projects/llm-development/output/template-clean.pptx`。页数和 SHA 见原评分目录及 `pptx/` 导航。
- B：`evaluation/candidate-169150635/decks/projects/llm-development/output/大模型发展.pptx`。页数和 SHA 见原评分目录及 `pptx/` 导航。

两次独立评分均为 1，Harness Stop / Bridge revoke、任务与基础设施清理、4 个任务/评分 Sandbox 删除确认均通过；额外 BPF 短探针 Sandbox 也已删除。网络策略仍为 `assumed_not_enforced`，不声称已强制禁网或 fully isolation-verified Goodput。

## 复现身份

- A Run ID：`20261105T024317.821829723Z-profiling-birth-fix-r2-20261105-a`。
- B Run ID：`20261105T024647.998321813Z-profiling-birth-fix-r2-20261105-b`。
- Binary SHA：`8e57893c0eef0eb1cc6ed93cc3b3f2ccab701dce90a54ec76182a590f00068fd`。
- 镜像与模板、三域配置、Tape SHA 和来源文件见 `collection-provenance.json` 与各组 `profiling-config.json`。
- 本包验证范围为真实任务、命令/身份/内核来源一致性、原件完整性和原生可读性，不提供自动性能归因结论。

不包含完整 Tape、私有 env/profile、密钥或完整模型 SSE。原件保留真实命令/输出；已知私有值扫描结果写入封包回执，不宣称可识别任意未知秘密。
