# 华为 Sandbox BPF 修复交接与复测

2026-11-05。范围：华为 AgentSphere 灰度 x86 Sandbox，五页 PPT 的新 profiling 模板。**当前 BPF 尚未恢复；用户已明确要求先记遗留、暂停处理。** 后续恢复时需要平台提供支持这些能力的运行内核，再按下方清单复验。没有把 perf、strace 或 ECS 上的 BPF 结果冒充 Sandbox 的 BPF 采集。

## 已经定位到哪一层

| 检查 | 本次华为 Sandbox 实测 | 含义 |
| --- | --- | --- |
| 运行内核 | `6.6.0-72.0.0.76.r1893_129.hce3.x86_64` | 由平台提供的 Guest 内核，不是容器镜像里的软件包 |
| 直接创建一个 hash map | 同一进程直接调用 `bpf(BPF_MAP_CREATE)`，返回 `-1 / errno 38 / ENOSYS` | 绕过 bpftrace 的参数解析和探测逻辑，基础入口仍不可用 |
| 探针进程权限 | UID 0；CapEff `000001ffffffffff`；Seccomp 0、filters 0、NoNewPrivs 0 | 没有该进程常规 seccomp 过滤或缺少有效 capability 的证据 |
| bpftrace 实际 syscall | MAP_CREATE、PROG_LOAD、BTF_GET_NEXT_ID 均 ENOSYS | 不仅是某一个 tracepoint 或某一种 map 的问题 |
| 内核符号 | `__x64_sys_bpf` 为 `W` 弱符号，`sys_ni_syscall` 为 `T`；所查 BPF 加载实现符号未见 | 与 Linux 的未实现系统调用弱入口高度一致 |
| tracefs | `/proc/filesystems` 没有注册 tracefs；两个常见 tracing 路径均不存在 | 不是只缺一次用户态 mount；本次没有盲目修改挂载或 sysctl |
| 当前只读配置证据 | `/proc/config.gz`、精确版本 `/boot/config-*`、`/lib/modules/*/config` 均不存在 | 没拿到实际 HCE 编译配置，不能宣称已直接验证某个 CONFIG 值 |
| BTF 和相关 sysctl | BTF 文件及三个 BPF sysctl 路径均不存在 | 旁证；缺 BTF 本身不能解释基础 map 创建 ENOSYS |

上游 Linux 的 x86 `__COND_SYSCALL` 提供弱入口，回落到返回 ENOSYS 的 `sys_ni_syscall`。当前实测与运行内核未提供 BPF 实现高度一致；最终仍由平台核对 HCE 实际配置和定制实现。[x86 syscall wrapper](https://github.com/torvalds/linux/blob/v6.6/arch/x86/include/asm/syscall_wrapper.h)、[未实现 syscall](https://github.com/torvalds/linux/blob/v6.6/kernel/sys_ni.c)

## 平台需要完成的修复

1. 核对上述**运行内核**的真实构建配置，提供能执行 `bpf()` 的内核。基础配置涉及 `CONFIG_BPF_SYSCALL=y` 和其依赖；这项是编译期布尔项，安装新 bpftrace、headers 或复制 BTF 文件不能补出缺失的系统调用。[BPF 配置](https://github.com/torvalds/linux/blob/v6.6/kernel/bpf/Kconfig)
2. 对本期 syscall 观测，确认 `CONFIG_BPF_EVENTS`、`CONFIG_PERF_EVENTS`、`CONFIG_FTRACE_SYSCALLS` 及 tracing 依赖有效，tracefs 已注册，`syscalls:sys_enter_read` 可见且可附着。Kprobe/uprobe 另按实际脚本开启相应配置，不把所有探针都当成已经验证。[Trace 配置](https://github.com/torvalds/linux/blob/v6.6/kernel/trace/Kconfig)
3. 需要类型解析的脚本再补齐匹配该内核的 BTF。当前最小 read 计数验收不以 BTF 文件存在代替真实 attach。
4. 用新内核创建新的 Sandbox；确认模板指向的新实例实际切换了内核，再运行下面的同一探针。不要只更新容器镜像或模板名称。

若平台确认上述配置已启用，仍返回 ENOSYS，请继续核查定制内核的 syscall 分派和平台拦截路径。现有用户态证据不能替代这一步。当前已实现的 AgentSphere 接入没有已核实的“切换 Guest 内核”配置入口，不能伪造一个 template 字段解决。

## 可以直接运行的复测

交付 ZIP 内含 `probe_bpf_kernel_portable.py`。在待验证 Sandbox 中以 root 执行：

```sh
python3 probe_bpf_kernel_portable.py > bpf-result.json
```

前提是镜像已有 Python、bpftrace、strace；当前 profiling 镜像均已预装。脚本短时运行，不启动常驻采样，不改 sysctl，不采集模型对话或凭据。创建的 map fd 会关闭；若需要检查 tracefs 挂载，只尝试独立子 mount namespace，退出即释放。

查看 JSON 中：

- `direct_bpf_map_create`：必须获得有效 fd，不是 ENOSYS/EPERM；脚本随即关闭 fd。
- `map_program`：实际 map 和程序加载必须退出 0，保留完整 strace。
- `actual_read_probe`：按 `cpid` 过滤本脚本启动的 `/bin/cat /dev/null`，实际附着、运行和退出；必须退出 0，并产生正数 `target_read_count`。
- `capability_status`：上述三项均成立才是 `passed`。`--info` 或 `-l` 返回 0 不算能力通过。

脚本退出 0 表示诊断报告已生成，能力是否通过以 `capability_status` 为准。通过最小探针后，还需将 bpftrace 加入 A Worker、A ECS Harness、B Harness 的实际采集配置，完成五页 PPT A/B、ready/停止/导出及原件校验，才能标记完整业务采集完成。每个域独立验收；原六工具结果保留。

## 控制组与 ARIES 侧修正

同一便携脚本已在 ECS `6.8.0-106-generic` 实测：直接 map 创建成功；bpftrace 程序加载退出 0；目标子进程 read 计数 4，退出 0。它证明探针本身可工作，**不代表华为 Sandbox 已修好**。

ARIES 的 `deploy/profiling/check.py` 同步修正能力展示：`--info` 只记信息收集；`-l` 区分发现目标、空结果和警告，不再因退出码 0 泛称 `passed`。保留全部原始输出和原有失败分类，安装检查外层语义不变。11 项 ECS 测试已通过，完整发布检查正在执行；现有冻结镜像没有被这项文案修正冒充更新。

## 原件与完成条件

证据根：ECS `/opt/aries-artifacts/profiling-birth-fix-20261105/`。本次短探针均由本任务创建，使用后 DELETE 并 GET 404 确认，无模型调用。

- `bpf-current-guest/`：初次 strace 和指定 tracepoint 失败原件。
- `bpf-kernel-guest/`：直接 syscall、进程权限、内核符号和 tracefs 诊断；原件 SHA256 `5681fda9772fbe107e080de60da076080a0bdb2a36bd3874f9a495d6c0b85b07`。
- `bpf-portable-guest/`：最终便携探针在华为 Sandbox 的真实结果及清理回执。
- `bpf-ecs-control.json`：同脚本 ECS 控制组的完整结果。

交付包保留以上选定原件、脚本与逐文件 SHA 清单。未提供实际 HCE 内核源码/构建配置，不把推断写成已核验；不以修正文案作为 BPF 功能修复。退出条件是：平台内核能力恢复 → 同脚本实测通过 → A/B 实际 BPF 采集通过并交付原件。
