import ctypes
import errno
import gzip
import json
import os
from pathlib import Path
import platform
import re
import subprocess
import tempfile
import time


def run(argv, timeout=15):
    began = time.monotonic_ns()
    try:
        p = subprocess.run(argv, capture_output=True, text=True, timeout=timeout)
        return dict(argv=argv, returncode=p.returncode, stdout=p.stdout, stderr=p.stderr,
                    duration_ns=time.monotonic_ns() - began)
    except (OSError, subprocess.TimeoutExpired) as e:
        return dict(argv=argv, error_type=type(e).__name__, error=str(e))


def read(path):
    try:
        return dict(path=path, content=Path(path).read_text())
    except OSError as e:
        return dict(path=path, errno=e.errno, error=str(e))


kernel = platform.release()
security = {line.split(':', 1)[0]: line.split(':', 1)[1].strip()
            for line in Path('/proc/self/status').read_text().splitlines()
            if line.startswith(('Cap', 'Seccomp', 'NoNewPrivs:'))}
result = dict(kernel=kernel, architecture=platform.machine(), uid=os.getuid(),
              process_security=security, filesystems=read('/proc/filesystems'),
              namespaces={str(p.name): os.readlink(p) for p in Path('/proc/self/ns').iterdir()},
              config_sources=[], sysctls={}, mount_attempt=None)
pattern = re.compile(r'^(?:# )?CONFIG_(?:BPF|BPF_SYSCALL|BPF_JIT|BPF_EVENTS|PERF_EVENTS|FTRACE|FTRACE_SYSCALLS|TRACING|TRACEPOINTS|KPROBES|KPROBE_EVENTS|UPROBE_EVENTS|DEBUG_INFO_BTF|IKCONFIG|IKCONFIG_PROC)(?:=| )')
for path in ['/proc/config.gz', '/boot/config-' + kernel, '/lib/modules/' + kernel + '/config']:
    try:
        content = gzip.decompress(Path(path).read_bytes()).decode() if path.endswith('.gz') else Path(path).read_text()
        result['config_sources'].append(dict(path=path, entries=[x for x in content.splitlines() if pattern.match(x)]))
    except OSError as e:
        result['config_sources'].append(dict(path=path, errno=e.errno, error=str(e)))
for path in ['/proc/sys/kernel/unprivileged_bpf_disabled', '/proc/sys/kernel/bpf_stats_enabled', '/proc/sys/net/core/bpf_jit_enable']:
    result['sysctls'][path] = read(path)
result['mounts'] = [line for line in Path('/proc/self/mountinfo').read_text().splitlines()
                    if any(x in line for x in ('/sys/kernel', 'tracefs', 'debugfs', 'securityfs'))]
symbols = []
try:
    for line in Path('/proc/kallsyms').read_text().splitlines():
        parts = line.split()
        if len(parts) > 2 and re.match(r'^(?:__x64_sys_bpf|__arm64_sys_bpf|__sys_bpf|bpf_map_create|bpf_prog_load|bpf_check|sys_ni_syscall|perf_event_open|__x64_sys_perf_event_open)$', parts[2]):
            symbols.append(dict(kind=parts[1], name=parts[2]))
    result['kernel_symbols'] = symbols
except OSError as e:
    result['kernel_symbols_error'] = dict(errno=e.errno, error=str(e))
result['version'] = run(['bpftrace', '--version'])
result['info'] = run(['bpftrace', '--info'])

# Direct syscall in this very process: no bpftrace feature probing or seccomp ambiguity.
class MapAttr(ctypes.Structure):
    _fields_ = [('map_type', ctypes.c_uint32), ('key_size', ctypes.c_uint32),
                ('value_size', ctypes.c_uint32), ('max_entries', ctypes.c_uint32),
                ('map_flags', ctypes.c_uint32)]

numbers = {'x86_64': 321, 'aarch64': 280}
if platform.machine() in numbers:
    libc = ctypes.CDLL(None, use_errno=True)
    libc.syscall.restype = ctypes.c_long
    attr = MapAttr(1, 4, 8, 1, 0)
    ctypes.set_errno(0)
    rc = libc.syscall(ctypes.c_long(numbers[platform.machine()]), ctypes.c_int(0),
                      ctypes.byref(attr), ctypes.c_uint(ctypes.sizeof(attr)))
    err = ctypes.get_errno() if rc < 0 else 0
    result['direct_bpf_map_create'] = dict(returncode=rc, errno=err, errno_name=errno.errorcode.get(err),
                                          syscall_number=numbers[platform.machine()], process_security=security)
    if rc >= 0:
        os.close(rc)

result['tracefs'] = []
for path in ['/sys/kernel/tracing', '/sys/kernel/debug/tracing']:
    row = dict(path=path, exists=Path(path).exists())
    try:
        row['read_events'] = [x for x in (Path(path) / 'available_events').read_text().splitlines()
                              if x in ('syscalls:sys_enter_read', 'syscalls:sys_exit_read')]
    except OSError as e:
        row['errno'] = e.errno
    result['tracefs'].append(row)

# A mount, if needed, is tried only in a private child mount namespace and disappears on exit.
filesystems = result['filesystems'].get('content', '')
if 'tracefs' in filesystems and not any(row.get('read_events') for row in result['tracefs']):
    with tempfile.TemporaryDirectory(prefix='aries-tracefs-check-') as tmp:
        script = 'mount --make-rprivate / && mount -t tracefs tracefs "$1" && cat "$1/events/syscalls/sys_enter_read/format"'
        result['mount_attempt'] = run(['unshare', '--mount', '--', 'sh', '-c', script, 'tracefs-check', tmp])
else:
    result['mount_attempt'] = dict(status='not_needed' if any(row.get('read_events') for row in result['tracefs']) else 'tracefs_not_registered')

script = 'BEGIN { @aries_check = 1; printf("aries_bpf_probe\\n"); exit(); }'
with tempfile.TemporaryDirectory(prefix='aries-bpf-check-') as tmp:
    trace = Path(tmp) / 'syscalls.txt'
    result['map_program'] = run(['strace', '-f', '-e', 'trace=bpf', '-o', str(trace), 'bpftrace', '-e', script])
    result['bpf_syscalls'] = trace.read_text() if trace.exists() else None
result['actual_read_probe'] = run(['bpftrace', '-e', 'tracepoint:syscalls:sys_enter_read /pid == cpid/ { @aries_reads = count(); }', '-c', '/bin/cat /dev/null'], 8)
match = re.search(r'@aries_reads:\s*(\d+)', result['actual_read_probe'].get('stdout', ''))
result['target_read_count'] = int(match[1]) if match else None
result['capability_status'] = 'passed' if result.get('direct_bpf_map_create', {}).get('returncode', -1) >= 0 and result['map_program'].get('returncode') == 0 and result['actual_read_probe'].get('returncode') == 0 and result['target_read_count'] and result['target_read_count'] > 0 else 'unavailable_or_unproven'
print(json.dumps(result))
