# 五页PPT A/B：完整Profiling原件与命令索引

**本轮真实华为A/B五页PPT任务均通过独立评分（score=1），三域六工具采集、启动覆盖、原件完整性和原生perf回读均通过。** A记录32条完整命令，B记录39条完整命令；A全部32条perf生命期匹配，B为38条matched、1条unknown。**B第5条命令文本、ToolCall和退出结果完整，但回调时进程出生身份不可用，不能确认其perf生命期关联。**

| 原件入口 | 实际采集对象 | 原始导出文件/字节 | 命令记录与perf生命期关联 |
| --- | --- | --- | --- |
| `A/ecs-harness/command-profile/` | A：ECS外置Harness | 37 / 133,272,772 | `runtime_context_only`；业务Tool命令属于Worker域 |
| `A/sandbox-worker/command-profile/` | A：Sandbox Worker + Tool | 115 / 12,544,761 | 32条recorded/completed，32 matched |
| `B/sandbox-harness/command-profile/` | B：Sandbox 内 Harness + Tool | 120 / 82,722,254 | 39条recorded/completed，38 matched、1 unknown |

直接打开本轮五页输出：[A final.pptx](A/evaluation/candidate-1657584619/decks/projects/llm-development/output/final.pptx)、[B final.pptx](B/evaluation/candidate-734058880/decks/projects/llm-development/output/final.pptx)；[B 大模型发展.pptx](B/evaluation/candidate-734058880/decks/projects/llm-development/output/大模型发展.pptx)与B final内容SHA相同。原始评分与文件对应关系见各组`evaluation/`，不把六个归档文件计成六次成功任务。

共272份原始导出文件、228,539,787字节；三域各六工具completed、native ready早于同PID exec，各有Python perf map。导出SHA/大小、原始命令行号、ToolCall权威span及SSE命令hash关联均通过；本次原生shell入口文本与ToolCall文本全部相同。`completed`只说明进程退出，具体返回值见每条原始记录。

PPT保留A两份、B四份全部实际导出文件，包括三页的`content.pptx`中间件和五页输出。两次Harness、Verifier、Stop/revoke、任务/基础设施清理均通过，各两个Sandbox和自有adapter均确认删除。`network_policy=assumed_not_enforced`保留，评分通过不表示网络强制隔离已经证实。

本包面向接收原始材料的分析人员，保留原生profiling文件、命令索引、进程生命周期、符号材料、五页PPT输入/输出和独立评分证据。包内不生成热点、CPU归因结论、火焰图或Console页面。更早的V1、外置Harness与启动期包仍保留各自原版本，不被本包覆盖。

## 先看哪些文件

1. 用整包SHA及解压目录中的`SHA256SUMS`核验传输；`manifest.json`列出每项文件的大小、SHA和原件/派生说明。
2. 在`A/`或`B/`中确认PPT评分、Stop/revoke与清理回执，业务成功和采集完整性分开看。
3. 阅读对应域`command-profile/COMMANDS.md`，按完整命令、ToolCall或原生process_id找到记录。
4. 在同目录`command-index.json`查看命令身份、原始事件行号、`perf_selection`与原件引用。没有明确关联时保持未知。
5. 需要进一步读取工具原件时，先看`profile-index.json`中的范围、版本、参数、就绪/停止/截断状态，再打开实际文件。具体方法见`COLLECTION.md`。

## 目录与三种执行域

目录如下；每个实际文件的来源、大小和SHA以`manifest.json`为准。

```text
README.md
COLLECTION.md
manifest.json
SHA256SUMS
collection-provenance.json
A/
  ecs-harness/command-profile/
  sandbox-worker/
    jiuwen-process-events.jsonl
    jiuwen-process-index.json
    command-profile/
  identity/
  pptx/
  evaluation/
  run-cleanup-proof.json
  completion.json
B/
  sandbox-harness/
    jiuwen-process-events.jsonl
    jiuwen-process-index.json
    command-profile/
  identity/
  pptx/
  evaluation/
  run-cleanup-proof.json
  completion.json
verification/
```

| 路径 | 实际对象 | 如何理解命令记录 |
| --- | --- | --- |
| `A/ecs-harness/command-profile/` | ECS Docker中的外置Harness | 模型调度/Agent运行时上下文。A的Tool命令在Sandbox Worker执行；本域没有本地命令账本时索引应为`runtime_context_only`，不能把A的Tool命令复制归属到此域 |
| `A/sandbox-worker/command-profile/` | 华为Sandbox中的Worker及其被实际采集的后代 | 从本域命令账本连接A的ToolCall、process_id与已观察内核生命周期 |
| `B/sandbox-harness/command-profile/` | B：Sandbox 内 Harness + Tool | 同时保留Harness启动运行和实际Tool进程；命令账本连接B的ToolCall、process_id及perf已观察后代的内核生命期。目录名只表示附着根，不表示排除Tool |

ECS和Sandbox有各自的PID空间、boot_id及单调时钟。相同PID、相同命令文本或相近时间都不建立跨域关联。ECS容器中的guest范围表示容器可见的ECS内核/系统视图，不是容器私有CPU、内存或磁盘归因。B采集Harness和Tool，并不表示六工具都能按cmd归因；各工具仍保留自己的guest/runtime范围。

每个`command-profile/`保留：

- `COMMANDS.md`、`command-index.json`：可读目录和机器可读命令导航。
- `profile-index.json`：执行域、目标、实际工具配置、版本、时钟、启动覆盖、停止及缺失状态。
- `export-manifest.json`：从执行域导出的原件大小/SHA与状态。
- `launch-target.json`、`controller-runtime-ready.json`及已有启动回执：同PID启动门、实际exec请求/观察与运行时身份。
- 各工具原生目录：perf二进制与文本解码、sysstat原生记录、stdout/stderr、符号和工具自己的索引；以实际原件清单为准。

`command-index.json.sources`中的`../jiuwen-process-*.json[l]`相对域目录保留，因此能直接找到生产者原始记录。额外的`identity/`材料只补上下文，不替代这些原件。

## 本轮六项工具做什么

三个域均实际运行下列六项工具，状态全部completed；就绪、停止及原件回读证据逐域保留。

| 工具 | 选择 | 原始材料用途与边界 |
| --- | --- | --- |
| perf | record，runtime，99 Hz，fp调用栈 | 保存CPU采样、FORK/EXIT/COMM任务事件和可得调用栈。原件为perf.data及保留task events的perf.script。采样和生命周期事件作用不同，命令有身份不代表有CPU采样点 |
| vmstat | guest，1秒 | 系统运行队列、内存、交换、I/O及CPU概况；排除累计首报后核验就绪，仍不是逐命令用量 |
| iostat | guest，1秒 | 系统CPU与块设备I/O；设备统计不能直接归给某条命令 |
| mpstat | guest，1秒 | 各CPU活动统计；周期可能错过短操作 |
| sar | guest，1秒 | 按实际argv记录的系统活动及原生二进制；保存原格式和版本供回读 |
| pidstat | runtime，1秒 | 所选PID/线程的实际周期统计，受保护I/O维度可读性单独记录；不能扩展为全部后代或短命令覆盖 |

strace、numastat、dmesg、bpftrace、blktrace属于可单独配置的其他collector，本轮没有选择不等于它们采集了零事件。fio是显式工作负载，不会在PPT运行中自动执行。安装可用、权限可用、实际启动、实际就绪和产物可回读是不同状态。

## 命令索引包含什么

`commands[]`按原生`spawn_requested`记录建立，包含序号、原生`process_id`、`identity`、完整shell命令或exec argv、cwd、原始spawn/connected/exit或spawn_failure事件，以及原始账本`source_lines`。这里的完整命令是实际`create_subprocess`入口接收的参数，文本未截断；不从内核COMM短名称还原命令，不采集env或stdin。

该入口参数不一定逐字等于ToolCall的command。固定原生运行时会解析执行计划，例如stream且非background时加入缓冲包装，exec分支也可能使用`bash -c`。按request_id和tool_call_id关联原始ToolCall证据，分别保留入口文本和文本比较结果；合法包装差异不等于账本损坏，也不通过反向剥壳猜测原始命令。

一个ToolCall可以触发多次进程创建，也可以没有OS子进程；同一个后台进程也可能被后续调用等待。索引保留原生关联，不强制一条ToolCall等于一个PID。`lifecycle_status=completed`仅表示观察到进程退出，是否成功仍要看原始returncode；它不是整项PPT任务的成功判定。

`perf_selection`中的“kernel选择”指由内核FORK/EXIT/COMM证据确认的进程生命期及已观察到的父子关系，**不是筛选kernel CPU栈**。连接依据为同执行域/boot_id、原生PID出生ticks、spawn到connected的时间窗口与保留的时钟校准；不能只靠PID或最近时间猜测。确认后给出可定位的processes/threads、PID/TID、fork/exit单调时间和perf.script原始行号。

顶层命令账本状态与每条`perf_selection.status`分别读取：账本`complete`不证明每条命令都有perf关联；`matched`也不证明完整进程树、完整CPU用量或零采样丢失。`partial`、`unknown`及issues/reason都保留真实缺口，未记录退出不能用整个run结束时间补造。

B第5条是本轮实际保留的关联缺口：命令清理项目内误建目录、建立工作目录并列目录，原生退出码为0。`jiuwen-process-events.jsonl`第29/30/31行分别保留spawn、connection和exit；connection记录PID 300，但出生ticks、PPID和cwd不可用。原始perf文本虽存在同PID的FORK/EXIT候选，缺出生身份时索引不凭邻近时间补造关联。具体事件时间、原件行号和查阅方法见`COLLECTION.md`及`verification/B/sandbox-harness/known-gap.json`；未采集到专门的reap/errno证据，不能断言身份缺失的唯一原因。

## 启动窗口、开关和限制

采集从同PID启动门等待时开始；工具实际native ready后，所有者放行原生exec，再覆盖可观察的初始化、业务与退出。gate等待段和原生初始化段分别解释，不能把整段当作初始化成本。Sandbox创建、镜像准备以及具备执行能力之前的内部过程不在范围内。readiness早于exec不保证每个瞬间或短初始化动作都被采样。

全局`profiling.enabled=false`优先；全局开启时仅运行`enabled`未设为false的工具。省略tools兼容perf，显式空数组或全部关闭不启动collector/启动门；A ECS Harness须另设`external_harness=true`。关闭不修改原生命令与环境。实际配置仅保存不含私有字段的profiling块。

缺工具或就绪超时会保留partial，不能当作零消耗；取消不按诊断降级继续业务。默认每文件2GiB可按配置放大，传输按64MiB块核验整文件SHA，但停止、导出和原生解码仍有限时。原件完整性通过不代表无限容量、完整符号或所有短命进程都可见。

## PPT输入、输出和独立验收

各组使用自己的原成功Tape，zero timing/workload replay与原五页PPT任务保持不变。原任务文字为：`幻灯片 生成一份关于大模型发展的pptx材料，写5页。` A/B Tape不同，不依据两组耗时直接比较placement优劣。

`evaluation/`原样保留整个原始评分目录，包括`decks/`下全部PPTX、manifest、capture、report及stdout/stderr，以免破坏Verifier原有相对路径。`pptx/`保存输入说明和输出导航清单，每项链接到`../evaluation/...`原件；评分目录之外发现的PPTX按原路径保存到`pptx/extra/`。这包括未满足五页要求的中间文件，不只保留最终成功文件。原路径、大小、SHA、评分对应关系及未导出的缺失范围随清单记录。

输入文字由本轮冻结源码`pkg/benchmark/codingcase/pptx.go`中的`pptxInstruction`明确摘录，并记录整个源码文件SHA与候选身份；它是有来源的输入摘录，不冒充复制了不存在的独立原始输入文件。

业务、命令账本、perf关联、采集原件、评分、隔离/撤权、停止和删除各自有结论。网络隔离若仍使用`assumed_not_enforced`，不能写成已强制隔离。验证目录应保留原失败及补验，而非用最终通过覆盖历史失败。

不装入完整Tape、私有env/profile、凭据或完整模型SSE。包内保留完整任务命令与输出，不改变其内容；已知私有值扫描的范围和结果由封包回执说明，不宣称能识别任意未知秘密。

实际PPT清单如下，文件SHA及原任务路径见各组`pptx/`导航清单：

| 组 | 文件名 | 页数 | 字节 |
| --- | --- | --- | --- |
| A | content.pptx | 3 | 129,018 |
| A | final.pptx | 5 | 38,083 |
| B | content.pptx | 3 | 122,312 |
| B | final.pptx | 5 | 37,213 |
| B | template-clean.pptx | 5 | 31,430 |
| B | 大模型发展.pptx | 5 | 37,213 |

## 版本与验收记录

新observer r2镜像已发布并核验OCI index `sha256:205a3e6b82ca7016093c09685e8741c310d20c8c5a56ec6ee2e9a83db9ef2d73`；本轮专用华为模板`5f0a562b-a6d7-46dc-a041-27b2223b750a:5b360076-d211-49dd-85b9-a422dedf45c0`已READY并回读4 vCPU/8192 MiB。模板准备不等于Sandbox运行验收。

本轮候选二进制SHA为`1e330f1309fef942dbba5502354654eacec2239508b9c6724ce658fec511f394`，1,078项冻结源码聚合SHA为`3bbd2da85c8450a71c06a123303010d962dc56c3d422198a82736be608f7eee2`。ECS的build、test、test-race、lint、integration五项均通过；受测源码与二进制未变，发布检查自身新增Docker资源为空。显式云fixture及缺少checkout的SWEAtlas条件跳过范围另列，不能用发布检查代替本轮真实A/B。

原完整unit曾因新测试fixture未初始化而panic，修复只涉及测试初始化，生产二进制SHA未变；原失败日志和全部发布日志保留在ECS准备证据目录，本包附首轮失败及修复后完整发布的简洁回执。这不是业务回放或采集原件失败。observer首次未认证push失败，以及后续将OCI index误认作config摘要的发布校验器失败也在ECS保留；包内附最终发布核验回执，镜像未重建，最终registry原件核验通过。

本轮Run ID：

- A：`20261104T081703.526073002Z-profiling-command-index-20261104-a`
- B：`20261104T082034.626789682Z-profiling-command-index-20261104-b`

独立验收源收据为`delivery-validation-1793780648653004343/verification.json`，SHA256为`f8330ce21d6ca63f09841c96a75a763cad0e7190e83f6604d492cd2026d2e019`；本包`verification/`保留相关原件。验收范围是原件完整性、实际命令/身份/内核来源一致性及原生可读性，没有性能分析。归档名为`ARIES-five-page-PPT-profiling-huawei-AB-20261104.tar.gz`；整包SHA以归档旁的`.sha256`和封包回执为准，包内逐文件校验见`SHA256SUMS`。
