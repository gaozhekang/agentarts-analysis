# 命令与 Profiling 原件目录

执行域：sandbox；角色：harness；命令账本状态：complete。

从下表找到命令，再查看完整命令和 JSON 中的 `perf_selection`。该字段只提供同域内已证实的内核进程生命期与原件位置，不计算热点、CPU 用量或火焰图。系统级资源文件属于整体背景，不能直接归给某条命令。短命令可能没有 CPU 采样点。

采样丢失状态：`native_decode_retained_not_quantified`。进程关联成功不表示全树、全部采样或零丢失。

| 序号 | ToolCall | PID | 命令记录 | 进程终态 | perf 进程关联 |
|---|---|---:|---|---|---|
| [1](#cmd-0001) | `call_00_CLXHMD8XwNYPIwTcOvC07886` | 265 | recorded | completed | matched |
| [2](#cmd-0002) | `call_00_voWVH66HKc4aZZJYtXDr5820` | 269 | recorded | completed | matched |
| [3](#cmd-0003) | `call_00_ZnXU6vsV4gvKasc1X1nt3240` | 273 | recorded | completed | matched |
| [4](#cmd-0004) | `call_00_YgMalFMpBqh016NkAfoJ1844` | 292 | recorded | completed | matched |
| [5](#cmd-0005) | `call_00_WMn8tGVObVXGEz6Zfjmn9942` | 300 | recorded | completed | unknown |
| [6](#cmd-0006) | `call_00_3LtROSd6ZoX4ndPjaM9K7165` | 310 | recorded | completed | matched |
| [7](#cmd-0007) | `call_01_AzB47q3ehCAsGuxjEddb6676` | 337 | recorded | completed | matched |
| [8](#cmd-0008) | `call_00_jR7VTDMEWm6fN0DLS8dp5133` | 346 | recorded | completed | matched |
| [9](#cmd-0009) | `call_00_i9k4ina1OtR9IApaSfGK5871` | 361 | recorded | completed | matched |
| [10](#cmd-0010) | `call_00_v4md3Seq8VUnyyGBfVMb0036` | 373 | recorded | completed | matched |
| [11](#cmd-0011) | `call_00_u29jLE2xrkEA7cM8UmQK6790` | 385 | recorded | completed | matched |
| [12](#cmd-0012) | `call_00_IfZpu4BIXIJ4i5rFqoPp1181` | 393 | recorded | completed | matched |
| [13](#cmd-0013) | `call_00_LrQXGoidmwBtl7JdmkY52375` | 403 | recorded | completed | matched |
| [14](#cmd-0014) | `call_01_xn45i8ACskBAHPXakgTs4577` | 422 | recorded | completed | matched |
| [15](#cmd-0015) | `call_00_AsvO3PW1hF9lst16RO5c8076` | 425 | recorded | completed | matched |
| [16](#cmd-0016) | `call_00_4TN230NHvhUDnMG2LqCa5229` | 472 | recorded | completed | matched |
| [17](#cmd-0017) | `call_00_YaBJo5iZhCSnAVESKzUh1612` | 478 | recorded | completed | matched |
| [18](#cmd-0018) | `call_00_KwJiEXrq07UiUtsxDlb77791` | 482 | recorded | completed | matched |
| [19](#cmd-0019) | `call_00_DYuDH8Q69nmlmCtecqnq5403` | 492 | recorded | completed | matched |
| [20](#cmd-0020) | `call_00_wVXxlPO2gW2JZzszqs8q5300` | 495 | recorded | completed | matched |
| [21](#cmd-0021) | `call_00_7QdY8byTdUs2fxDTplIp7563` | 502 | recorded | completed | matched |
| [22](#cmd-0022) | `call_00_PhsNoYLdYouWGkFSEnlQ2433` | 507 | recorded | completed | matched |
| [23](#cmd-0023) | `call_00_oizxPyss844D3SuNha1o7631` | 513 | recorded | completed | matched |
| [24](#cmd-0024) | `call_00_Hh5VJEwxOunPvd4Oon8Z3804` | 522 | recorded | completed | matched |
| [25](#cmd-0025) | `call_00_MBuwACjnHohQ8rUjXNpY7008` | 525 | recorded | completed | matched |
| [26](#cmd-0026) | `call_00_qVgmIIllzvrzkN94OHxG0482` | 533 | recorded | completed | matched |
| [27](#cmd-0027) | `call_00_1TeWO8UsYHYoaLzxt1WM4617` | 536 | recorded | completed | matched |
| [28](#cmd-0028) | `call_00_I2bYLAQHnKNvgOCZUYp45596` | 539 | recorded | completed | matched |
| [29](#cmd-0029) | `call_00_96rLJWWUEKNAKZbbmbwJ8904` | 549 | recorded | completed | matched |
| [30](#cmd-0030) | `call_00_PjFvSRRWKtVm0nrMqpbb8182` | 552 | recorded | completed | matched |
| [31](#cmd-0031) | `call_00_CWbPN29LggdjHPwgj20u5030` | 554 | recorded | completed | matched |
| [32](#cmd-0032) | `call_00_XmFHZVcwbYAQnUirAjQv3877` | 565 | recorded | completed | matched |
| [33](#cmd-0033) | `call_00_fdygoJqO07eQPimAkIrn0390` | 568 | recorded | completed | matched |
| [34](#cmd-0034) | `call_00_des6RMnlvIJpjxu7ZJhq7049` | 591 | recorded | completed | matched |
| [35](#cmd-0035) | `call_00_JFex3rtyvnB6guiWtZzc9758` | 594 | recorded | completed | matched |
| [36](#cmd-0036) | `call_00_ub36yqSavpXV979lnpuT0882` | 651 | recorded | completed | matched |
| [37](#cmd-0037) | `call_00_L6ayvu2iJyMgO8KYADTP6798` | 654 | recorded | completed | matched |
| [38](#cmd-0038) | `call_00_oIqEjVxlHollWYLwoDX71245` | 657 | recorded | completed | matched |
| [39](#cmd-0039) | `call_01_dof0AYhTuGHbtfqMIySG6211` | 673 | recorded | completed | matched |

<a id="cmd-0001"></a>

## 命令 1

ToolCall：`call_00_CLXHMD8XwNYPIwTcOvC07886`；进程记录：`b4c4ee12a9bd4cf1b947c358dd418993`。

```text
find /run/aries-jiuwen-43075c2743787d78/home/data -type d -name "ppt-creation" 2>/dev/null; echo "---"; find / -maxdepth 6 -type d -name "ppt-creation" 2>/dev/null | head -20
```

工作目录：`/workspace/aries-case`。

请求创建单调时钟：`47317770875 ns`。进程连接回调：`47321827258 ns`。退出回调：`47549373344 ns`；返回码：`0`。

perf 关联：**matched**；unique native birth/window anchor; descendants follow observed fork parents only

[原始 perf.script](00-perf/perf.script)，筛选进程与内核时间边界见 [command-index.json](command-index.json) 的第 1 条命令。

<a id="cmd-0002"></a>

## 命令 2

ToolCall：`call_00_voWVH66HKc4aZZJYtXDr5820`；进程记录：`700ad068f3c0490eb878aae5f0619dd1`。

```text
ls -la /run/aries-jiuwen-43075c2743787d78/home/data/service_default/agent_default/agent/jiuwenclaw_workspace/ 2>/dev/null; echo "=== skills ==="; ls -la /run/aries-jiuwen-43075c2743787d78/home/data/service_default/agent_default/agent/jiuwenclaw_workspace/skills/ 2>/dev/null; echo "=== find skills ==="; find /run -maxdepth 8 -type d -name "skills" 2>/dev/null
```

工作目录：`/workspace/aries-case`。

请求创建单调时钟：`48182192223 ns`。进程连接回调：`48186027886 ns`。退出回调：`48190113511 ns`；返回码：`1`。

perf 关联：**matched**；unique native birth/window anchor; descendants follow observed fork parents only

[原始 perf.script](00-perf/perf.script)，筛选进程与内核时间边界见 [command-index.json](command-index.json) 的第 2 条命令。

<a id="cmd-0003"></a>

## 命令 3

ToolCall：`call_00_ZnXU6vsV4gvKasc1X1nt3240`；进程记录：`9424aa099c63424aa4b7074e782c41c5`。

```text
find / -name "finalize_deck.py" 2>/dev/null | head; echo "=== template.pptx ==="; find / -name "template.pptx" -path "*ppt*" 2>/dev/null | head; echo "=== pptxgenjs ==="; find / -name "pptxgenjs*" -maxdepth 8 2>/dev/null | head
```

工作目录：`/workspace/aries-case`。

请求创建单调时钟：`48920810646 ns`。进程连接回调：`48921512446 ns`。退出回调：`49676759296 ns`；返回码：`0`。

perf 关联：**matched**；unique native birth/window anchor; descendants follow observed fork parents only

[原始 perf.script](00-perf/perf.script)，筛选进程与内核时间边界见 [command-index.json](command-index.json) 的第 3 条命令。

<a id="cmd-0004"></a>

## 命令 4

ToolCall：`call_00_YgMalFMpBqh016NkAfoJ1844`；进程记录：`bbadfc553b8b42838240be0a1e0f3d5c`。

```text
mkdir -p /workspace/aries-case/projects/llm-development/{sources,analysis,assets,output,qa} && cp /opt/jiuwenswarm/jiuwenswarm/resources/agent/workspace/skills/ppt-creation/base/evidence-plan.json /opt/jiuwenswarm/jiuwenswarm/resources/agent/workspace/skills/ppt-creation/base/evidence-plan.schema.json /opt/jiuwenswarm/jiuwenswarm/resources/agent/workspace/skills/ppt-creation/base/execution-lock-reference.json /opt/jiuwenswarm/jiuwenswarm/resources/agent/workspace/skills/ppt-creation/base/execution-lock.schema.json /workspace/aries-case/projects/llm-development/ && echo "工作区已建立" && ls -la /workspace/aries-case/projects/llm-development/
```

工作目录：`/workspace/aries-case`。

请求创建单调时钟：`53136733541 ns`。进程连接回调：`53148140652 ns`。退出回调：`53150205614 ns`；返回码：`0`。

perf 关联：**matched**；unique native birth/window anchor; descendants follow observed fork parents only

[原始 perf.script](00-perf/perf.script)，筛选进程与内核时间边界见 [command-index.json](command-index.json) 的第 4 条命令。

<a id="cmd-0005"></a>

## 命令 5

ToolCall：`call_00_WMn8tGVObVXGEz6Zfjmn9942`；进程记录：`e8ebc29cb1db47509aa979777d81f833`。

```text
cd /workspace/aries-case/projects/llm-development && rmdir '{sources,analysis,assets,output,qa}' 2>/dev/null; mkdir -p sources analysis assets output qa && ls -la
```

工作目录：`/workspace/aries-case`。

请求创建单调时钟：`54104865410 ns`。进程连接回调：`54120605032 ns`。退出回调：`54120798703 ns`；返回码：`0`。

perf 关联：**unknown**；Native child birth identity unavailable; PID alone cannot establish a kernel lifetime.

[原始 perf.script](00-perf/perf.script)，筛选进程与内核时间边界见 [command-index.json](command-index.json) 的第 5 条命令。

<a id="cmd-0006"></a>

## 命令 6

ToolCall：`call_00_3LtROSd6ZoX4ndPjaM9K7165`；进程记录：`8ffd3f068d89483d951e368e97c589ea`。

```text
node --version; echo "---npm root---"; ls /opt/aries-presentation/node_modules/pptxgenjs/package.json 2>/dev/null && echo "pptxgenjs ok"; echo "---sharp---"; ls /opt/aries-presentation/node_modules/sharp/package.json 2>/dev/null && echo "sharp ok" || echo "no sharp"; echo "---python---"; python3 --version; echo "---soffice/pdftoppm---"; soffice --version 2>/dev/null | head -1; pdftoppm -v 2>/dev/null | head -1; echo "---scripts---"; ls /opt/jiuwenswarm/jiuwenswarm/resources/agent/workspace/skills/ppt-creation/scripts/*.py | head -30
```

工作目录：`/workspace/aries-case`。

请求创建单调时钟：`57197089346 ns`。进程连接回调：`57201083159 ns`。退出回调：`58245689760 ns`；返回码：`0`。

perf 关联：**matched**；unique native birth/window anchor; descendants follow observed fork parents only

[原始 perf.script](00-perf/perf.script)，筛选进程与内核时间边界见 [command-index.json](command-index.json) 的第 6 条命令。

<a id="cmd-0007"></a>

## 命令 7

ToolCall：`call_01_AzB47q3ehCAsGuxjEddb6676`；进程记录：`dfd77e2d21d440e69682b7496be5cda0`。

```text
cd /workspace/aries-case/projects/llm-development && node /opt/jiuwenswarm/jiuwenswarm/resources/agent/workspace/skills/ppt-creation/scripts/validate-execution-lock.js execution-lock.json --phase design && echo "=== execution-lock design OK ===" && node /opt/jiuwenswarm/jiuwenswarm/resources/agent/workspace/skills/ppt-creation/scripts/validate-evidence-plan.js evidence-plan.json --phase design && echo "=== evidence-plan design OK ==="
```

工作目录：`/workspace/aries-case/projects/llm-development`。

请求创建单调时钟：`64759301024 ns`。进程连接回调：`64760128544 ns`。退出回调：`64975968104 ns`；返回码：`1`。

perf 关联：**matched**；unique native birth/window anchor; descendants follow observed fork parents only

[原始 perf.script](00-perf/perf.script)，筛选进程与内核时间边界见 [command-index.json](command-index.json) 的第 7 条命令。

<a id="cmd-0008"></a>

## 命令 8

ToolCall：`call_00_jR7VTDMEWm6fN0DLS8dp5133`；进程记录：`eeaf4205e0234a9c9dcdb657a9716e64`。

```text
cd /workspace/aries-case/projects/llm-development && node /opt/jiuwenswarm/jiuwenswarm/resources/agent/workspace/skills/ppt-creation/scripts/validate-execution-lock.js execution-lock.json --phase design && echo "=== execution-lock design OK ===" && node /opt/jiuwenswarm/jiuwenswarm/resources/agent/workspace/skills/ppt-creation/scripts/validate-evidence-plan.js evidence-plan.json --phase design && echo "=== evidence-plan design OK ==="
```

工作目录：`/workspace/aries-case/projects/llm-development`。

请求创建单调时钟：`68719291425 ns`。进程连接回调：`68722283558 ns`。退出回调：`68853012434 ns`；返回码：`0`。

perf 关联：**matched**；unique native birth/window anchor; descendants follow observed fork parents only

[原始 perf.script](00-perf/perf.script)，筛选进程与内核时间边界见 [command-index.json](command-index.json) 的第 8 条命令。

<a id="cmd-0009"></a>

## 命令 9

ToolCall：`call_00_i9k4ina1OtR9IApaSfGK5871`；进程记录：`4463940c0d8b49ebb094e0bc89ea9a23`。

```text
cat /opt/aries-presentation/node_modules/pptxgenjs/package.json | grep -E '"main"|"version"|"name"'; echo "---dist---"; ls /opt/aries-presentation/node_modules/pptxgenjs/dist/ 2>/dev/null; echo "---test require---"; node -e "const P=require('/opt/aries-presentation/node_modules/pptxgenjs'); const p=new P(); console.log('pptxgenjs ok, version:', p.version||'n/a')"
```

工作目录：`/workspace/aries-case`。

请求创建单调时钟：`69853025814 ns`。进程连接回调：`69853828755 ns`。退出回调：`69974293444 ns`；返回码：`0`。

perf 关联：**matched**；unique native birth/window anchor; descendants follow observed fork parents only

[原始 perf.script](00-perf/perf.script)，筛选进程与内核时间边界见 [command-index.json](command-index.json) 的第 9 条命令。

<a id="cmd-0010"></a>

## 命令 10

ToolCall：`call_00_v4md3Seq8VUnyyGBfVMb0036`；进程记录：`4a71b1ba96a74082a612a0a65d4244ed`。

```text
cd /workspace/aries-case/projects/llm-development && node slides.js
```

工作目录：`/workspace/aries-case/projects/llm-development`。

请求创建单调时钟：`76440114056 ns`。进程连接回调：`76440876376 ns`。退出回调：`76578309774 ns`；返回码：`0`。

perf 关联：**matched**；unique native birth/window anchor; descendants follow observed fork parents only

[原始 perf.script](00-perf/perf.script)，筛选进程与内核时间边界见 [command-index.json](command-index.json) 的第 10 条命令。

<a id="cmd-0011"></a>

## 命令 11

ToolCall：`call_00_u29jLE2xrkEA7cM8UmQK6790`；进程记录：`6af0dbcacce940688dce780b2aebf77a`。

```text
cd /workspace/aries-case/projects/llm-development && python3 /opt/jiuwenswarm/jiuwenswarm/resources/agent/workspace/skills/ppt-creation/scripts/finalize_deck.py output/content.pptx output/final.pptx --cover-title "大模型发展" --cover-meta "||2026-10-27"
```

工作目录：`/workspace/aries-case/projects/llm-development`。

请求创建单调时钟：`77805153822 ns`。进程连接回调：`77805941773 ns`。退出回调：`78539170136 ns`；返回码：`1`。

perf 关联：**matched**；unique native birth/window anchor; descendants follow observed fork parents only

[原始 perf.script](00-perf/perf.script)，筛选进程与内核时间边界见 [command-index.json](command-index.json) 的第 11 条命令。

<a id="cmd-0012"></a>

## 命令 12

ToolCall：`call_00_IfZpu4BIXIJ4i5rFqoPp1181`；进程记录：`e13a3390e0ed49699b7a92516036e313`。

```text
cd /workspace/aries-case/projects/llm-development && python3 /opt/jiuwenswarm/jiuwenswarm/resources/agent/workspace/skills/ppt-creation/scripts/finalize_deck.py output/content.pptx output/final.pptx --cover-title "大模型发展" --cover-meta "||2026-10-27" --keep-workdir /tmp/llm-keep 2>&1 | tail -5; echo "=== slide8.xml 220-240 ==="; sed -n '220,240p' /tmp/llm-keep/template/ppt/slides/slide8.xml
```

工作目录：`/workspace/aries-case/projects/llm-development`。

请求创建单调时钟：`80924977182 ns`。进程连接回调：`80925732213 ns`。退出回调：`81572638852 ns`；返回码：`0`。

perf 关联：**matched**；unique native birth/window anchor; descendants follow observed fork parents only

[原始 perf.script](00-perf/perf.script)，筛选进程与内核时间边界见 [command-index.json](command-index.json) 的第 12 条命令。

<a id="cmd-0013"></a>

## 命令 13

ToolCall：`call_00_LrQXGoidmwBtl7JdmkY52375`；进程记录：`92c70d0c8a8d4335afd3de15aae5e8ae`。

```text
cd /workspace/aries-case/projects/llm-development && node slides.js && python3 /opt/jiuwenswarm/jiuwenswarm/resources/agent/workspace/skills/ppt-creation/scripts/finalize_deck.py output/content.pptx output/final.pptx --cover-title "大模型发展" --cover-meta "||2026-10-27"
```

工作目录：`/workspace/aries-case/projects/llm-development`。

请求创建单调时钟：`86176762060 ns`。进程连接回调：`86179495373 ns`。退出回调：`86992168664 ns`；返回码：`0`。

perf 关联：**matched**；unique native birth/window anchor; descendants follow observed fork parents only

[原始 perf.script](00-perf/perf.script)，筛选进程与内核时间边界见 [command-index.json](command-index.json) 的第 13 条命令。

<a id="cmd-0014"></a>

## 命令 14

ToolCall：`call_01_xn45i8ACskBAHPXakgTs4577`；进程记录：`d294f0441f0347308316a53fab2d562a`。

```text
cd /workspace/aries-case/projects/llm-development && echo "=== qa_geometry ===" && python3 /opt/jiuwenswarm/jiuwenswarm/resources/agent/workspace/skills/ppt-creation/scripts/qa_geometry.py output/final.pptx; echo "=== qa_density ===" && python3 /opt/jiuwenswarm/jiuwenswarm/resources/agent/workspace/skills/ppt-creation/scripts/qa_density.py output/final.pptx --lock execution-lock.json
```

工作目录：`/workspace/aries-case/projects/llm-development`。

请求创建单调时钟：`88143248196 ns`。进程连接回调：`88144124807 ns`。退出回调：`88319219567 ns`；返回码：`1`。

perf 关联：**matched**；unique native birth/window anchor; descendants follow observed fork parents only

[原始 perf.script](00-perf/perf.script)，筛选进程与内核时间边界见 [command-index.json](command-index.json) 的第 14 条命令。

<a id="cmd-0015"></a>

## 命令 15

ToolCall：`call_00_AsvO3PW1hF9lst16RO5c8076`；进程记录：`ea264ceffbbc4544a438793a60a7d6ec`。

```text
cd /workspace/aries-case/projects/llm-development && python3 /opt/jiuwenswarm/jiuwenswarm/resources/agent/workspace/skills/ppt-creation/scripts/opc/unpack.py /opt/jiuwenswarm/jiuwenswarm/resources/agent/workspace/skills/ppt-creation/references/template.pptx /tmp/tpl-unpack >/dev/null 2>&1; echo "=== 各 layout 的占位符类型 (ph type) ==="; for f in /tmp/tpl-unpack/ppt/slideLayouts/slideLayout*.xml; do echo "--- $(basename $f) ---"; grep -o 'type="[a-zA-Z]*"' "$f" | sort -u | tr '\n' ' '; echo; done
```

工作目录：`/workspace/aries-case`。

请求创建单调时钟：`89912630575 ns`。进程连接回调：`89913379496 ns`。退出回调：`90037914608 ns`；返回码：`0`。

perf 关联：**matched**；unique native birth/window anchor; descendants follow observed fork parents only

[原始 perf.script](00-perf/perf.script)，筛选进程与内核时间边界见 [command-index.json](command-index.json) 的第 15 条命令。

<a id="cmd-0016"></a>

## 命令 16

ToolCall：`call_00_4TN230NHvhUDnMG2LqCa5229`；进程记录：`0ee1467432a44fcda8e415b5fae118c5`。

```text
cd /workspace/aries-case/projects/llm-development && python3 /opt/jiuwenswarm/jiuwenswarm/resources/agent/workspace/skills/ppt-creation/scripts/opc/unpack.py output/final.pptx /tmp/final-unpack >/dev/null 2>&1; echo "=== slide6(P02) 的 layout 引用 ==="; cat /tmp/final-unpack/ppt/slides/_rels/slide6.xml.rels; echo; echo "=== slide6 中是否含 title/ctrTitle 占位符 ==="; grep -o 'type="[a-zA-Z]*"' /tmp/final-unpack/ppt/slides/slide6.xml | sort | uniq -c
```

工作目录：`/workspace/aries-case/projects/llm-development`。

请求创建单调时钟：`92253521149 ns`。进程连接回调：`92254307509 ns`。退出回调：`92396485304 ns`；返回码：`0`。

perf 关联：**matched**；unique native birth/window anchor; descendants follow observed fork parents only

[原始 perf.script](00-perf/perf.script)，筛选进程与内核时间边界见 [command-index.json](command-index.json) 的第 16 条命令。

<a id="cmd-0017"></a>

## 命令 17

ToolCall：`call_00_YaBJo5iZhCSnAVESKzUh1612`；进程记录：`7c0c9f525c754e16a1b69ae578f3f36b`。

```text
grep -n "Click to edit\|duplicate-chrome\|duplicate_chrome\|Master\|master" /opt/jiuwenswarm/jiuwenswarm/resources/agent/workspace/skills/ppt-creation/scripts/qa_geometry.py | head -40
```

工作目录：`/workspace/aries-case`。

请求创建单调时钟：`93417944252 ns`。进程连接回调：`93418685593 ns`。退出回调：`93420291494 ns`；返回码：`0`。

perf 关联：**matched**；unique native birth/window anchor; descendants follow observed fork parents only

[原始 perf.script](00-perf/perf.script)，筛选进程与内核时间边界见 [command-index.json](command-index.json) 的第 17 条命令。

<a id="cmd-0018"></a>

## 命令 18

ToolCall：`call_00_KwJiEXrq07UiUtsxDlb77791`；进程记录：`7bb8695a7b73479393295b935d4b01e4`。

```text
echo "=== slideMaster1.xml 中 'Click to edit' 文字 ==="; grep -o 'Click to edit[^<]*' /tmp/final-unpack/ppt/slideMasters/slideMaster1.xml | sort | uniq -c; echo "=== slideMaster1.xml 占位符类型 ==="; grep -o 'type="[a-zA-Z]*"' /tmp/final-unpack/ppt/slideMasters/slideMaster1.xml | sort | uniq -c; echo "=== 封面 slide1 是否含 title 占位符与 meta ==="; grep -o 'type="[a-zA-Z]*"' /tmp/final-unpack/ppt/slides/slide1.xml | sort | uniq -c
```

工作目录：`/workspace/aries-case`。

请求创建单调时钟：`95375702159 ns`。进程连接回调：`95376461260 ns`。退出回调：`95379946923 ns`；返回码：`0`。

perf 关联：**matched**；unique native birth/window anchor; descendants follow observed fork parents only

[原始 perf.script](00-perf/perf.script)，筛选进程与内核时间边界见 [command-index.json](command-index.json) 的第 18 条命令。

<a id="cmd-0019"></a>

## 命令 19

ToolCall：`call_00_DYuDH8Q69nmlmCtecqnq5403`；进程记录：`854eda93e2e2419e96fed4420d801e05`。

```text
grep -n "Click\|has_text\|def parse_slide\|def label\|ph\b\|placeholder\|inherit" /opt/jiuwenswarm/jiuwenswarm/resources/agent/workspace/skills/ppt-creation/scripts/qa_geometry.py | head -50
```

工作目录：`/workspace/aries-case`。

请求创建单调时钟：`97917113513 ns`。进程连接回调：`97917845344 ns`。退出回调：`97919519755 ns`；返回码：`0`。

perf 关联：**matched**；unique native birth/window anchor; descendants follow observed fork parents only

[原始 perf.script](00-perf/perf.script)，筛选进程与内核时间边界见 [command-index.json](command-index.json) 的第 19 条命令。

<a id="cmd-0020"></a>

## 命令 20

ToolCall：`call_00_wVXxlPO2gW2JZzszqs8q5300`；进程记录：`70057a86c31c4c6b912bf1c7042df0dd`。

```text
grep -n "Click\|placeholder\|ph type\|title\|clean\|strip\|remove" /opt/jiuwenswarm/jiuwenswarm/resources/agent/workspace/skills/ppt-creation/scripts/merge_slides.py | head -30; echo "=== make_blank_template.py 是否清理占位符 ==="; grep -n "Click\|title\|body\|placeholder\|ph " /opt/jiuwenswarm/jiuwenswarm/resources/agent/workspace/skills/ppt-creation/scripts/make_blank_template.py | head -30
```

工作目录：`/workspace/aries-case`。

请求创建单调时钟：`100580457003 ns`。进程连接回调：`100581394714 ns`。退出回调：`100584624346 ns`；返回码：`0`。

perf 关联：**matched**；unique native birth/window anchor; descendants follow observed fork parents only

[原始 perf.script](00-perf/perf.script)，筛选进程与内核时间边界见 [command-index.json](command-index.json) 的第 20 条命令。

<a id="cmd-0021"></a>

## 命令 21

ToolCall：`call_00_7QdY8byTdUs2fxDTplIp7563`；进程记录：`3bdd8e2a4f8c43128d67654547fb8bea`。

```text
echo "=== 模板解包目录中所有 'Click to edit' 文字分布 ==="; grep -rl "Click to edit" /tmp/tpl-unpack/ 2>/dev/null; echo "=== 具体文字 ==="; grep -rho "Click to edit[^<]*" /tmp/tpl-unpack/ 2>/dev/null | sort | uniq -c
```

工作目录：`/workspace/aries-case`。

请求创建单调时钟：`105319055912 ns`。进程连接回调：`105319808743 ns`。退出回调：`105323574125 ns`；返回码：`0`。

perf 关联：**matched**；unique native birth/window anchor; descendants follow observed fork parents only

[原始 perf.script](00-perf/perf.script)，筛选进程与内核时间边界见 [command-index.json](command-index.json) 的第 21 条命令。

<a id="cmd-0022"></a>

## 命令 22

ToolCall：`call_00_PhsNoYLdYouWGkFSEnlQ2433`；进程记录：`9b627520268e468fa087d2695f65db95`。

```text
cd /workspace/aries-case/projects/llm-development && python3 -c "
import zipfile, re
src = '/opt/jiuwenswarm/jiuwenswarm/resources/agent/workspace/skills/ppt-creation/references/template.pptx'
dst = 'output/template-clean.pptx'
with zipfile.ZipFile(src) as zin, zipfile.ZipFile(dst, 'w', zipfile.ZIP_DEFLATED) as zout:
    for item in zin.infolist():
        data = zin.read(item.filename)
        if item.filename.endswith('.xml'):
            text = data.decode('utf-8')
            text = re.sub(r'Click to edit[^<]*', '', text)
            data = text.encode('utf-8')
        zout.writestr(item, data)
print('template-clean.pptx written')
" && python3 /opt/jiuwenswarm/jiuwenswarm/resources/agent/workspace/skills/ppt-creation/scripts/opc/unpack.py output/template-clean.pptx /tmp/tpl-clean-check >/dev/null 2>&1 && echo "clean template unpack OK" && grep -rc "Click to edit" /tmp/tpl-clean-check/ 2>/dev/null | grep -v ':0' | head || echo "no Click to edit remains"
```

工作目录：`/workspace/aries-case/projects/llm-development`。

请求创建单调时钟：`107007627760 ns`。进程连接回调：`107008365841 ns`。退出回调：`107159264813 ns`；返回码：`0`。

perf 关联：**matched**；unique native birth/window anchor; descendants follow observed fork parents only

[原始 perf.script](00-perf/perf.script)，筛选进程与内核时间边界见 [command-index.json](command-index.json) 的第 22 条命令。

<a id="cmd-0023"></a>

## 命令 23

ToolCall：`call_00_oizxPyss844D3SuNha1o7631`；进程记录：`aeb2057fc71f4377ae12d7ef0fd53f0d`。

```text
cd /workspace/aries-case/projects/llm-development && python3 /opt/jiuwenswarm/jiuwenswarm/resources/agent/workspace/skills/ppt-creation/scripts/finalize_deck.py output/content.pptx output/final.pptx --cover-title "大模型发展" --cover-meta "||2026-10-27" --template output/template-clean.pptx 2>&1 | tail -8
```

工作目录：`/workspace/aries-case/projects/llm-development`。

请求创建单调时钟：`108172767825 ns`。进程连接回调：`108173581056 ns`。退出回调：`108892214017 ns`；返回码：`0`。

perf 关联：**matched**；unique native birth/window anchor; descendants follow observed fork parents only

[原始 perf.script](00-perf/perf.script)，筛选进程与内核时间边界见 [command-index.json](command-index.json) 的第 23 条命令。

<a id="cmd-0024"></a>

## 命令 24

ToolCall：`call_00_Hh5VJEwxOunPvd4Oon8Z3804`；进程记录：`7682c1f2ed704fa686d0870b77d29cff`。

```text
cd /workspace/aries-case/projects/llm-development && echo "=== qa_geometry ===" && python3 /opt/jiuwenswarm/jiuwenswarm/resources/agent/workspace/skills/ppt-creation/scripts/qa_geometry.py output/final.pptx; echo "=== qa_density ===" && python3 /opt/jiuwenswarm/jiuwenswarm/resources/agent/workspace/skills/ppt-creation/scripts/qa_density.py output/final.pptx --lock execution-lock.json
```

工作目录：`/workspace/aries-case`。

请求创建单调时钟：`110031931131 ns`。进程连接回调：`110032639222 ns`。退出回调：`110206279700 ns`；返回码：`1`。

perf 关联：**matched**；unique native birth/window anchor; descendants follow observed fork parents only

[原始 perf.script](00-perf/perf.script)，筛选进程与内核时间边界见 [command-index.json](command-index.json) 的第 24 条命令。

<a id="cmd-0025"></a>

## 命令 25

ToolCall：`call_00_MBuwACjnHohQ8rUjXNpY7008`；进程记录：`783b2f6d7be84c489bba432a847f6c77`。

```text
echo "=== master/layout 中所有非空 a:t 文字（示例占位符文字）==="; grep -rho '<a:t>[^<]*</a:t>' /tmp/tpl-unpack/ppt/slideMasters/slideMaster1.xml | sort | uniq -c; echo "=== 各 layout 中的示例文字 ==="; grep -rho '<a:t>[^<]*</a:t>' /tmp/tpl-unpack/ppt/slideLayouts/*.xml | sort | uniq -c | head -30
```

工作目录：`/workspace/aries-case`。

请求创建单调时钟：`111233557641 ns`。进程连接回调：`111234271721 ns`。退出回调：`111237619914 ns`；返回码：`0`。

perf 关联：**matched**；unique native birth/window anchor; descendants follow observed fork parents only

[原始 perf.script](00-perf/perf.script)，筛选进程与内核时间边界见 [command-index.json](command-index.json) 的第 25 条命令。

<a id="cmd-0026"></a>

## 命令 26

ToolCall：`call_00_qVgmIIllzvrzkN94OHxG0482`；进程记录：`6cbd01f471434732a1329750721b81a1`。

```text
cd /workspace/aries-case/projects/llm-development && python3 -c "
import zipfile, re
src = '/opt/jiuwenswarm/jiuwenswarm/resources/agent/workspace/skills/ppt-creation/references/template.pptx'
dst = 'output/template-clean.pptx'
with zipfile.ZipFile(src) as zin, zipfile.ZipFile(dst, 'w', zipfile.ZIP_DEFLATED) as zout:
    for item in zin.infolist():
        data = zin.read(item.filename)
        if item.filename.endswith('.xml'):
            text = data.decode('utf-8')
            text = re.sub(r'Click to edit[^<]*', '', text)
            text = re.sub(r'<a:t>(?:Second|Third|Fourth|Fifth) level</a:t>', '<a:t></a:t>', text)
            data = text.encode('utf-8')
        zout.writestr(item, data)
print('template-clean.pptx regenerated')
"
```

工作目录：`/workspace/aries-case/projects/llm-development`。

请求创建单调时钟：`112704814470 ns`。进程连接回调：`112707027132 ns`。退出回调：`112748571682 ns`；返回码：`0`。

perf 关联：**matched**；unique native birth/window anchor; descendants follow observed fork parents only

[原始 perf.script](00-perf/perf.script)，筛选进程与内核时间边界见 [command-index.json](command-index.json) 的第 26 条命令。

<a id="cmd-0027"></a>

## 命令 27

ToolCall：`call_00_1TeWO8UsYHYoaLzxt1WM4617`；进程记录：`53530a65d13e4e659c60858981060df8`。

```text
cd /workspace/aries-case/projects/llm-development && python3 -c "
import zipfile, re
def vis_len(t): return sum(1.0 if ord(c)>0x2E80 else 0.5 for c in t if not c.isspace())
with zipfile.ZipFile('output/final.pptx') as z:
    # 播放顺序
    prs = z.read('ppt/presentation.xml').decode('utf-8')
    ids = re.findall(r'<p:sldId[^>]*r:id=\"(rId\d+)\"', prs)
    rels = z.read('ppt/_rels/presentation.xml.rels').decode('utf-8')
    rid2slide = dict(re.findall(r'Id=\"(rId\d+)\"[^>]*slides/(slide\d+\.xml)\"', rels))
    print('播放顺序:', [rid2slide.get(i) for i in ids])
    # 每个 slide 的字量
    names = sorted([n for n in z.namelist() if re.fullmatch(r'ppt/slides/slide\d+\.xml', n)], key=lambda n:int(re.search(r'\d+',n.rsplit('/',1)[-1]).group()))
    for n in names:
        xml = z.read(n).decode('utf-8', errors='ignore')
        txt = ''.join(re.findall(r'<a:t>([^<]*)</a:t>', xml))
        print(f'{n.rsplit(chr(47),1)[-1]}: {round(vis_len(txt))} 字 | {txt[:60]!r}')
"
```

工作目录：`/workspace/aries-case/projects/llm-development`。

请求创建单调时钟：`115142748373 ns`。进程连接回调：`115143577263 ns`。退出回调：`115185989975 ns`；返回码：`0`。

perf 关联：**matched**；unique native birth/window anchor; descendants follow observed fork parents only

[原始 perf.script](00-perf/perf.script)，筛选进程与内核时间边界见 [command-index.json](command-index.json) 的第 27 条命令。

<a id="cmd-0028"></a>

## 命令 28

ToolCall：`call_00_I2bYLAQHnKNvgOCZUYp45596`；进程记录：`dbd2944f16fc48d584d71803c52b6244`。

```text
cd /workspace/aries-case/projects/llm-development && python3 /opt/jiuwenswarm/jiuwenswarm/resources/agent/workspace/skills/ppt-creation/scripts/finalize_deck.py output/content.pptx output/final.pptx --cover-title "大模型发展" --cover-meta "||2026-10-27" --template output/template-clean.pptx 2>&1 | tail -3 && python3 rename_slides.py output/final.pptx output/final.pptx
```

工作目录：`/workspace/aries-case/projects/llm-development`。

请求创建单调时钟：`121481443623 ns`。进程连接回调：`121484788806 ns`。退出回调：`122240202152 ns`；返回码：`0`。

perf 关联：**matched**；unique native birth/window anchor; descendants follow observed fork parents only

[原始 perf.script](00-perf/perf.script)，筛选进程与内核时间边界见 [command-index.json](command-index.json) 的第 28 条命令。

<a id="cmd-0029"></a>

## 命令 29

ToolCall：`call_00_96rLJWWUEKNAKZbbmbwJ8904`；进程记录：`beac8d4c1660405ca4df7b2a54cab1e2`。

```text
cd /workspace/aries-case/projects/llm-development && echo "=== qa_geometry ===" && python3 /opt/jiuwenswarm/jiuwenswarm/resources/agent/workspace/skills/ppt-creation/scripts/qa_geometry.py output/final.pptx; echo "=== qa_density ===" && python3 /opt/jiuwenswarm/jiuwenswarm/resources/agent/workspace/skills/ppt-creation/scripts/qa_density.py output/final.pptx --lock execution-lock.json
```

工作目录：`/workspace/aries-case/projects/llm-development`。

请求创建单调时钟：`123340432117 ns`。进程连接回调：`123344403740 ns`。退出回调：`123517802168 ns`；返回码：`1`。

perf 关联：**matched**；unique native birth/window anchor; descendants follow observed fork parents only

[原始 perf.script](00-perf/perf.script)，筛选进程与内核时间边界见 [command-index.json](command-index.json) 的第 29 条命令。

<a id="cmd-0030"></a>

## 命令 30

ToolCall：`call_00_PjFvSRRWKtVm0nrMqpbb8182`；进程记录：`89575665b4f44a21b95e5d4744a9ae01`。

```text
cd /workspace/aries-case/projects/llm-development && python3 -c "
import zipfile
with zipfile.ZipFile('output/final.pptx') as z:
    names = sorted([n for n in z.namelist() if 'ppt/slides/slide' in n and n.endswith('.xml') and '/_rels/' not in n])
    print('slide 文件:', [n.rsplit('/',1)[-1] for n in names])
    prs = z.read('ppt/presentation.xml').decode('utf-8')
    rids = __import__('re').findall(r'<p:sldId[^>]*r:id=\"(rId\d+)\"', prs)
    rels = z.read('ppt/_rels/presentation.xml.rels').decode('utf-8')
    rid2slide = dict(__import__('re').findall(r'Id=\"(rId\d+)\"[^>]*slides/(slide\d+\.xml)\"', rels))
    print('播放顺序:', [rid2slide.get(r) for r in rids])
"
```

工作目录：`/workspace/aries-case`。

请求创建单调时钟：`124756568936 ns`。进程连接回调：`124757277886 ns`。退出回调：`124796702655 ns`；返回码：`0`。

perf 关联：**matched**；unique native birth/window anchor; descendants follow observed fork parents only

[原始 perf.script](00-perf/perf.script)，筛选进程与内核时间边界见 [command-index.json](command-index.json) 的第 30 条命令。

<a id="cmd-0031"></a>

## 命令 31

ToolCall：`call_00_CWbPN29LggdjHPwgj20u5030`；进程记录：`3ee05f0f20134612a655f6e0e6b4641b`。

```text
cd /workspace/aries-case/projects/llm-development && python3 /opt/jiuwenswarm/jiuwenswarm/resources/agent/workspace/skills/ppt-creation/scripts/finalize_deck.py output/content.pptx output/final.pptx --cover-title "大模型发展" --cover-meta "||2026-10-27" --template output/template-clean.pptx 2>&1 | tail -2 && python3 rename_slides.py output/final.pptx output/final.pptx && echo "=== 校验 slide 文件名与播放顺序 ===" && python3 -c "
import zipfile, re
with zipfile.ZipFile('output/final.pptx') as z:
    names = sorted([n for n in z.namelist() if 'ppt/slides/slide' in n and n.endswith('.xml') and '/_rels/' not in n])
    print('slide 文件:', [n.rsplit('/',1)[-1] for n in names])
    prs = z.read('ppt/presentation.xml').decode('utf-8')
    rids = re.findall(r'<p:sldId[^>]*r:id=\"(rId\d+)\"', prs)
    rels = z.read('ppt/_rels/presentation.xml.rels').decode('utf-8')
    rid2slide = dict(re.findall(r'Id=\"(rId\d+)\"[^>]*slides/(slide\d+\.xml)\"', rels))
    print('播放顺序:', [rid2slide.get(r) for r in rids])
"
```

工作目录：`/workspace/aries-case/projects/llm-development`。

请求创建单调时钟：`128270061752 ns`。进程连接回调：`128274145595 ns`。退出回调：`129061178843 ns`；返回码：`0`。

perf 关联：**matched**；unique native birth/window anchor; descendants follow observed fork parents only

[原始 perf.script](00-perf/perf.script)，筛选进程与内核时间边界见 [command-index.json](command-index.json) 的第 31 条命令。

<a id="cmd-0032"></a>

## 命令 32

ToolCall：`call_00_XmFHZVcwbYAQnUirAjQv3877`；进程记录：`f74ff8acc15d4404b846be31f730a2c6`。

```text
cd /workspace/aries-case/projects/llm-development && echo "=== qa_geometry ===" && python3 /opt/jiuwenswarm/jiuwenswarm/resources/agent/workspace/skills/ppt-creation/scripts/qa_geometry.py output/final.pptx; echo "=== qa_density ===" && python3 /opt/jiuwenswarm/jiuwenswarm/resources/agent/workspace/skills/ppt-creation/scripts/qa_density.py output/final.pptx --lock execution-lock.json
```

工作目录：`/workspace/aries-case/projects/llm-development`。

请求创建单调时钟：`130101970285 ns`。进程连接回调：`130105328237 ns`。退出回调：`130277930210 ns`；返回码：`0`。

perf 关联：**matched**；unique native birth/window anchor; descendants follow observed fork parents only

[原始 perf.script](00-perf/perf.script)，筛选进程与内核时间边界见 [command-index.json](command-index.json) 的第 32 条命令。

<a id="cmd-0033"></a>

## 命令 33

ToolCall：`call_00_fdygoJqO07eQPimAkIrn0390`；进程记录：`d04f876fbd0642d8aa51733242e3276a`。

```text
cd /workspace/aries-case/projects/llm-development && node slides.js && python3 /opt/jiuwenswarm/jiuwenswarm/resources/agent/workspace/skills/ppt-creation/scripts/finalize_deck.py output/content.pptx output/final.pptx --cover-title "大模型发展" --cover-meta "||2026-10-27" --template output/template-clean.pptx 2>&1 | tail -2 && python3 rename_slides.py output/final.pptx output/final.pptx && echo "=== qa_geometry ===" && python3 /opt/jiuwenswarm/jiuwenswarm/resources/agent/workspace/skills/ppt-creation/scripts/qa_geometry.py output/final.pptx; echo "=== qa_density ===" && python3 /opt/jiuwenswarm/jiuwenswarm/resources/agent/workspace/skills/ppt-creation/scripts/qa_density.py output/final.pptx --lock execution-lock.json
```

工作目录：`/workspace/aries-case/projects/llm-development`。

请求创建单调时钟：`133813221178 ns`。进程连接回调：`133816690091 ns`。退出回调：`134889586299 ns`；返回码：`0`。

perf 关联：**matched**；unique native birth/window anchor; descendants follow observed fork parents only

[原始 perf.script](00-perf/perf.script)，筛选进程与内核时间边界见 [command-index.json](command-index.json) 的第 33 条命令。

<a id="cmd-0034"></a>

## 命令 34

ToolCall：`call_00_des6RMnlvIJpjxu7ZJhq7049`；进程记录：`03ddb0af3a4b42ebb7c6947598299eb3`。

```text
cd /workspace/aries-case/projects/llm-development && echo "=== audit_pptx ===" && python3 /opt/jiuwenswarm/jiuwenswarm/resources/agent/workspace/skills/ppt-creation/scripts/audit_pptx.py output/final.pptx --template output/template-clean.pptx --lock execution-lock.json --evidence-plan evidence-plan.json --report qa/structure.json; echo "=== validate.py ===" && python3 /opt/jiuwenswarm/jiuwenswarm/resources/agent/workspace/skills/ppt-creation/scripts/opc/validate.py output/final.pptx
```

工作目录：`/workspace/aries-case`。

请求创建单调时钟：`136040219415 ns`。进程连接回调：`136040992266 ns`。退出回调：`136217874668 ns`；返回码：`0`。

perf 关联：**matched**；unique native birth/window anchor; descendants follow observed fork parents only

[原始 perf.script](00-perf/perf.script)，筛选进程与内核时间边界见 [command-index.json](command-index.json) 的第 34 条命令。

<a id="cmd-0035"></a>

## 命令 35

ToolCall：`call_00_JFex3rtyvnB6guiWtZzc9758`；进程记录：`66da2597081f43a8851885508345a868`。

```text
cd /workspace/aries-case/projects/llm-development && soffice --headless --convert-to pdf --outdir output output/final.pptx 2>&1 | tail -2; echo "=== PDF 页数 ==="; pdfinfo output/final.pdf 2>/dev/null | grep -E "Pages|Page size"; echo "=== 生成缩略图 ==="; pdftoppm -jpeg -r 100 output/final.pdf qa/slide 2>&1; ls -la qa/*.jpg 2>/dev/null | head
```

工作目录：`/workspace/aries-case`。

请求创建单调时钟：`137428738643 ns`。进程连接回调：`137429453434 ns`。退出回调：`139673204816 ns`；返回码：`0`。

perf 关联：**matched**；unique native birth/window anchor; descendants follow observed fork parents only

[原始 perf.script](00-perf/perf.script)，筛选进程与内核时间边界见 [command-index.json](command-index.json) 的第 35 条命令。

<a id="cmd-0036"></a>

## 命令 36

ToolCall：`call_00_ub36yqSavpXV979lnpuT0882`；进程记录：`6c0f6c9c29a745e09148b36915517198`。

```text
cd /workspace/aries-case/projects/llm-development && pdftotext output/final.pdf - 2>/dev/null | head -120
```

工作目录：`/workspace/aries-case/projects/llm-development`。

请求创建单调时钟：`140604303237 ns`。进程连接回调：`140605089328 ns`。退出回调：`140627843325 ns`；返回码：`0`。

perf 关联：**matched**；unique native birth/window anchor; descendants follow observed fork parents only

[原始 perf.script](00-perf/perf.script)，筛选进程与内核时间边界见 [command-index.json](command-index.json) 的第 36 条命令。

<a id="cmd-0037"></a>

## 命令 37

ToolCall：`call_00_L6ayvu2iJyMgO8KYADTP6798`；进程记录：`04bfd754f39d474a8993cd7e7fb52f80`。

```text
cd /workspace/aries-case/projects/llm-development && pdftotext output/final.pdf - 2>/dev/null | tail -45
```

工作目录：`/workspace/aries-case/projects/llm-development`。

请求创建单调时钟：`141696242926 ns`。进程连接回调：`141696936296 ns`。退出回调：`141717559971 ns`；返回码：`0`。

perf 关联：**matched**；unique native birth/window anchor; descendants follow observed fork parents only

[原始 perf.script](00-perf/perf.script)，筛选进程与内核时间边界见 [command-index.json](command-index.json) 的第 37 条命令。

<a id="cmd-0038"></a>

## 命令 38

ToolCall：`call_00_oIqEjVxlHollWYLwoDX71245`；进程记录：`fdf4b09359aa451a848511fbda301d61`。

```text
cd /workspace/aries-case/projects/llm-development && node /opt/jiuwenswarm/jiuwenswarm/resources/agent/workspace/skills/ppt-creation/scripts/validate-execution-lock.js execution-lock.json --phase deliver && node /opt/jiuwenswarm/jiuwenswarm/resources/agent/workspace/skills/ppt-creation/scripts/validate-evidence-plan.js evidence-plan.json --phase deliver && echo "=== 交付校验通过 ===" && ls -la output/final.pptx
```

工作目录：`/workspace/aries-case/projects/llm-development`。

请求创建单调时钟：`142906890537 ns`。进程连接回调：`142907644208 ns`。退出回调：`143039953305 ns`；返回码：`0`。

perf 关联：**matched**；unique native birth/window anchor; descendants follow observed fork parents only

[原始 perf.script](00-perf/perf.script)，筛选进程与内核时间边界见 [command-index.json](command-index.json) 的第 38 条命令。

<a id="cmd-0039"></a>

## 命令 39

ToolCall：`call_01_dof0AYhTuGHbtfqMIySG6211`；进程记录：`cc397ab57cdc46bfa2e30ca991f0083e`。

```text
cd /workspace/aries-case/projects/llm-development && cp output/final.pptx "output/大模型发展.pptx" && ls -la "output/大模型发展.pptx"
```

工作目录：`/workspace/aries-case/projects/llm-development`。

请求创建单调时钟：`144145080964 ns`。进程连接回调：`144145913354 ns`。退出回调：`144148927247 ns`；返回码：`0`。

perf 关联：**matched**；unique native birth/window anchor; descendants follow observed fork parents only

[原始 perf.script](00-perf/perf.script)，筛选进程与内核时间边界见 [command-index.json](command-index.json) 的第 39 条命令。
